use DMF
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AB_PM_UNCalc_v2]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AB_PM_UNCalc_v2]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE AB_PM_UNCalc_v2 
  @id_Abon INT = NULL,
  @TechMode INT = 0 
 AS


SET NOCOUNT ON

CREATE TABLE #Period (
	[id_P] [int] IDENTITY (1, 1) ,
	[P_Year] [int] NOT NULL ,
	[P_Month] [int] NOT NULL ,
	[P_DDD] [DATETIME] NULL ,
        id_EQ [int],
        EQName VARCHAR(255), 
	[Tariff] [money] NULL ,
        [Tariff_real] [money] NULL ,

	[FullPayDate] [DATETIME] NULL ,
	[Total] [money] NULL,
        cmnt varchar(255)
) 


DECLARE @I INT, @N INT, @id_EQ INT, @id_City INT, @id_HomeType INT, @DateStart DATETIME

INSERT INTO #Period(P_Year, P_Month) EXEC AA_MonthList @id_Abon 
UPDATE #Period SET id_EQ = @id_EQ, P_DDD = CAST(CAST(P_Year as VARCHAR) + '.' + CAST(P_Month as VARCHAR) + '.01' as DateTime)

--select * from #Period return

SELECT @N = MAX(id_P), @DateStart = min(P_DDD) FROM #Period (NOLOCK)

SELECT @id_EQ = id_EQ, @id_City = id_City , @id_HomeType = id_HomeType
FROM Doc_Doc D (NOLOCK)
JOIN AB_Abon A (NOLOCK) ON A.id_Doc = D.id_DOc
WHERE id_Abon = @id_Abon

SELECT id_EQ, DateFromEQ, CAST(NULL as DATETIME) as DateToEQ INTO #TMP_EQ_Hst FROM AB_EQ EQ (NOLOCK) WHERE id_Abon = @id_Abon

INSERT INTO #TMP_EQ_Hst( id_EQ, DateFromEQ) VALUES(639, Getdate()-365*20)

UPDATE #TMP_EQ_Hst SET DateToEQ = (SELECT MIN(DateFromEQ) - 1 FROM #TMP_EQ_Hst X WHERE X.DateFromEQ > #TMP_EQ_Hst.DateFromEQ)
UPDATE #TMP_EQ_Hst SET DateToEQ = Getdate()+365*20 WHERE DateToEQ IS NULL

--select * from #TMP_EQ_Hst return

SELECT *, CAST(Null as DateTime) as DateTo INTO #TMP_EQPrice 
FROM Dic_EQPrice (NOLOCK) 
WHERE (641 = id_EQ OR id_EQ = @id_EQ OR id_EQ IN (SELECT id_EQ FROM #TMP_EQ_Hst (NOLOCK))) 
and (@id_City = id_City or id_City is null) AND (@id_HomeType = id_HomeType OR id_HomeType IS NULL)
ORDER BY DateFrom

--select @id_City, @id_HomeType, @id_EQ, * from #TMP_EQ_Hst

--UPDATE #TMP_EQ_Hst SET P_DDD = CAST(CAST(P_Year as VARCHAR) + '.' + CAST(P_Month as VARCHAR) + '.01' as DateTime)

UPDATE #TMP_EQPrice SET DateTo = isnull((SELECT MAX(DateFrom) FROM #TMP_EQPrice Z WHERE Z.id_EQ=#TMP_EQPrice.id_EQ AND Z.id_EQPrice<>#TMP_EQPrice.id_EQPrice AND Z.DateFrom>#TMP_EQPrice.DateFrom) - 1, Getdate()+3650)

--select 0, * from #Period
--select @id_EQ, @id_City, @id_HomeType  
--select * from #TMP_EQ_Hst
--select * from #TMP_EQPrice

SELECT * INTO #TMP_Cancel_Period FROM AB_Cancel_Period EQ (NOLOCK) WHERE id_Abon = @id_Abon
UPDATE #TMP_Cancel_Period SET DateTo = Getdate() + 1000 WHERE DateTo IS NULL

--select * from #TMP_Cancel_Period


UPDATE #Period SET id_EQ = ISNULL((SELECT MAX(id_EQ) FROM #TMP_EQ_Hst H WHERE DateFromEQ <= P_DDD AND DateToEQ > P_DDD), @id_EQ)
-- = COALESCE(
--(SELECT MAX(id_EQ) FROM #TMP_EQ_Hst H WHERE DateFromEQ =(SELECT MAX(DateFromEQ) FROM #TMP_EQ_Hst H WHERE DateFromEQ > P_DDD)), @id_EQ)


UPDATE #Period SET id_EQ = -641, cmnt = (SELECT MAX(CnComment) FROM #TMP_Cancel_Period (NOLOCK) WHERE P_DDD>=DateFrom AND P_DDD<=DateTo)
 WHERE EXISTS (SELECT * FROM #TMP_Cancel_Period (NOLOCK) WHERE P_DDD>=DateFrom AND P_DDD<=DateTo) 

--select *, id_EQ = COALESCE(
--(SELECT MAX(id_EQ) FROM #TMP_EQ_Hst H WHERE DateFromEQ =(SELECT MAX(DateFromEQ) FROM #TMP_EQ_Hst H WHERE DateFromEQ > P_DDD)), @id_EQ)
-- from #Period

UPDATE #Period SET Tariff = 
(SELECT MAX(Price) FROM #TMP_EQPrice Z WHERE DateFrom =(SELECT MAX(DateFrom) FROM #TMP_EQPrice H WHERE DateFrom < P_DDD AND ABS(#Period.id_EQ)=H.id_EQ AND Z.id_EQ=H.id_EQ))

--select * from #TMP_EQPrice H WHERE 641=H.id_EQ

--select (SELECT MAX(DateFrom) FROM #TMP_EQPrice H WHERE DateFrom < P_DDD AND 641=H.id_EQ) as xxxx,
--(SELECT MAX(Price) FROM #TMP_EQPrice Z WHERE DateFrom =(SELECT MAX(DateFrom) FROM #TMP_EQPrice H WHERE DateFrom < P_DDD AND 641=H.id_EQ)) as xxx , 
--* from #Period where id_EQ < 0
 

UPDATE #Period SET EQName = (SELECT MAX(Name) FROm DIC_EQ E WHERE E.id_EQ=ABS(#Period.id_EQ)),
  Total = (select sum(isnull(Tariff, 0)) from #Period Z WHERE Z.id_P <= #Period.id_P)  

UPDATE  #Period SET EQName = EQName+  CASE WHEN id_EQ < 0 THEN ' (Otkl)' ELSE '' END
UPDATE  #Period SET id_EQ = ABS(id_EQ)

--select 1, * from #Period
--select @id_EQ, @id_City, @id_HomeType  
--select * from #TMP_EQ_Hst
--select * from #TMP_EQPrice

SELECT IDENTITY (INT) as ID, 
PDate = COALESCE(PayDate, @DateStart, DateCreate), sum(Summ) as Summ, CAST(Null as DateTime) AS PM_DDD 
INTO #PM
FROM AB_PM (NOLOCK) 
WHERE id_Abon=@id_Abon and deleted=0
GROUP BY COALESCE(PayDate, @DateStart, DateCreate)
ORDER BY COALESCE(PayDate, @DateStart, DateCreate)

UPDATE #PM SET PM_DDD = CAST(CAST(Year(PDate) as VARCHAR) + '.' + CAST(Month(PDate) as VARCHAR) + '.01' as DateTime)

--select *, @DateStart from #PM

DECLARE @Tariff MONEY, @Tariff_OLD MONEY, @Tariff_real MONEY, @SUMM MONEY, @P_DDD DATETIME, @ID INT, @MAX_ID INT, @PDate DATETIME
SELECT @i = 1, @ID = 1
SELECT @MAX_ID = MAX(ID) FROM #PM
--select @ID, @MAX_ID, @i, @N
WHILE @ID <= @MAX_ID
BEGIN

  WHILE @i <= @N
  BEGIN
    SELECT @SUMM = sum(Summ), @PDate = max(CASE WHEN Summ > 0 THEN PDate ELSE NULL END) FROM #PM WHERE (ID <= @ID AND Summ > 0) OR (Summ < 0)

    SELECT @id_EQ=id_EQ, @Tariff = ISNULL(Tariff_real, Tariff), @P_DDD = P_DDD FROM #Period WHERE id_P = @i
    SELECT @Tariff_real = MAX(Price) FROM #TMP_EQPrice WHERE id_EQ = @id_EQ AND DateFrom <= @PDate AND DateTo >= @PDate

--select @Tariff_real, @SUMM

    IF @Tariff_real <= @SUMM 
    BEGIN
      UPDATE #Period SET FullPayDate = @PDate, Tariff_real = @Tariff_real WHERE id_P = @i
      INSERT INTO #PM(Summ, PDate) VALUES(-1 * @Tariff_real, @P_DDD)
     -- UPDATE #Period SET cmnt = 'sss'  WHERE id_P = @i 
      SET @i = @i + 1
    END
    ELSE
    BEGIN
      BREAK
    END
  END
  SET @ID = @ID + 1
END



--SELECT * FROM #PM
DELETE FROM #Period WHERE P_DDD > Getdate() AND FullPayDate IS NULL
UPDATE #Period SET Tariff_real = (SELECT MAX(Price) FROM #TMP_EQPrice Z WHERE #Period.id_EQ=Z.id_EQ AND DateFrom <= Getdate() AND DateTo >= Getdate())
WHERE FullPayDate IS NULL


DELETE FROM AB_Period WHERE id_Abon=@id_Abon

INSERT INTO AB_Period(id_Abon, P_Year, P_Month, P_DDD, id_EQ, EQName, Tariff, Tariff_real, FullPayDate, Total, cmnt)
SELECT @id_Abon, P_Year, P_Month, P_DDD, id_EQ, EQName, Tariff, Tariff_real, FullPayDate, Total, cmnt FROM #Period (NOLOCK)



DECLARE @Dept33 money, @LPD33 DateTime, @LPD DateTime, @LPD_XXX DateTime

Select @Dept33=SUM(Tariff_real), @LPD33 = MAX(P_DDD), @LPD = min(CASE WHEN FullPayDate is NOT null THEN NULL ELSE P_DDD END), @LPD_XXX = min(P_DDD)
FROM (
select Tariff_real, P_DDD, FullPayDate
from AB_Period (NOLOCK) where id_Abon = @id_Abon 

UNION ALL

SELECT -Summ as Tariff_real, Null as P_DDD, null
FROM AB_PM (NOLOCK) where id_Abon = @id_Abon and deleted=0) T

--select @LPD_XXX, @LPD, @Dept33 , @LPD33

UPDATE AB_Abon SET Dept33 = @Dept33, LPD33 = @LPD33, 
LPD = CASE
  WHEN @Dept33 <= 0 THEN @LPD33 
  WHEN @LPD_XXX < @LPD THEN @LPD 
  ELSE NULL 
END 
WHERE id_Abon=@id_Abon

IF @TechMode = 1 
BEGIN
  SELECT @Dept33 AS Dept33
  RETURN
END

SELECT * FROM AB_Period (NOLOCK) WHERE id_Abon=@id_Abon ORDER BY P_DDD DESC
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

