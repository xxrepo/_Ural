use DMF

GO


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AB_AbonGetList]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AB_AbonGetList]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE AB_AbonGetList
  @id_Doc INT = null,
  @id_Grp INT = null,
  @id_EQ INT = null,
  @id_City INT = null,
  @FIO VARCHAR(255) = null,
  @Street VARCHAR(255) = null,
  @DocNum VARCHAR(255) = null,
  @FlatNum INT = NULL,
  @Home VARCHAR(10) = NULL ,
  @Corp  VARCHAR(10) = NULL,
  @id_User INT = NULL,
  @DateFrom DATETIME = NULL,
  @DateTo DATETIME = NULL,
  @LetterIndex VARCHAR(10) = NULL,
  @DeptNew INT = NULL,
  @Podd VARCHAR(10) = NULL,
  @DeptM INTEGER = NULL,
  @DeptM2 INTEGER = NULL,
  @DeptSumm money = NULL,
  @DeptSumm2 money = NULL
 AS

SET NOCOUNT ON

SELECT @Home = UPPER(REPLACE(@Home, ' ', '')), @Corp = UPPER(REPLACE(@Corp, ' ', '')), @Podd = UPPER(REPLACE(@Podd, ' ', ''))

IF @Home in ('�', '�', '�', '�', '�', '�', '�', '�', '�', '�') SET @Home = '%' + @Home
IF @Corp in ('�', '�', '�', '�', '�', '�', '�', '�', '�', '�') SET @Corp = '%' + @Corp
IF @Podd in ('�', '�', '�', '�', '�', '�', '�', '�', '�', '�') SET @Podd = '%' + @Podd


DECLARE @CurDate DATETIME

SET @CurDate = CAST(CAST(Year(getdate()) as VARCHAR) + '.' + CAST(Month(getdate()) as VARCHAR) + '.1' as DateTime)

SELECT A.*, DocNum,
DateOpen,
DateClose,
D.id_City,
Street,
Home,
Corp,
Podd,
MNG_Name,
MNG_Cnt,
D.id_HomeType,
DocComment,  dbo.FormatInt(DocNum, 4) + dbo.FormatInt(FlatNum, 3) + ISNULL(LetterIndex, '') AS DN, EQ.Name as EQName, 
HT.Name as HTName, ISNULL( CP.Name + '/', '') + Ct.Name as CityName,
CP.Name as CityName1, Ct.Name as CityName2,
Dept_CNT = (SELECT count(DP.id_ABon) FROM AB_Dept_Period DP (NOLOCK) WHERE 1=0 and DP.id_Abon = A.id_Abon),
DeptNew = datediff(mm, coalesce(LPD, StartDate, DateOpen), @CurDate ) -- CASE WHEN LPD < @CurDate OR LPD IS NULL THEN 1 ELSE 0 END
, NeedPay = cast(null as money) 
, DeptSum_CUR = cast(null as money) 
INTO #T_R
from AB_Abon A (NOLOCK) 
JOIN Doc_Doc D (NOLOCK) On D.id_Doc = A.id_Doc
JOIN Dic_City Ct (NOLOCK) On Ct.id_City = D.id_City
LEFT JOIN Dic_City CP (NOLOCK) ON CP.id_City = Ct.PID
LEFT JOIN Dic_EQ EQ (NOLOCK) On EQ.id_EQ = A.id_EQ
LEFT JOIN Dic_HomeType HT (NOLOCK) On HT.id_HomeType = D.id_HomeType
where (A.deleted=0 OR @id_Grp < 0) AND 
(@id_Grp IS NULL OR  @id_Grp = -666  OR  @id_Grp = -1013  OR  @id_Grp = -1024  OR  @id_Grp = -1025  
OR (@id_Grp = -13 and A.deleted = 1)
OR (@id_Grp = -26 and A.deleted = 0)


) AND
(Upper(Street) like '%' + Upper(@Street) + '%' OR @Street IS NULL) AND 
(@DocNum IS NULL 
OR (dbo.FormatInt(DocNum, 4) + dbo.FormatInt(FlatNum, 3) + ISNULL(LetterIndex, '') like '0' + @DocNum + '%' )
OR (dbo.FormatInt(DocNum, 4) + dbo.FormatInt(FlatNum, 3) + ISNULL(LetterIndex, '') like '' + @DocNum + '%' )  )
AND (@FlatNum IS NULL OR FlatNum = @FlatNum )
AND (Upper(FIO) like '%' + Upper(@FIO) + '%' OR @FIO IS NULL)  
AND (Upper(LetterIndex) like '%' + Upper(@LetterIndex) + '%' OR @LetterIndex IS NULL)  
AND (@id_Doc IS NULL OR A.id_Doc = @id_Doc )

AND (@Podd IS NULL OR UPPER(REPLACE(Podd, ' ', '')) like Upper(@Podd) + '%' ) -- 
AND (@Home IS NULL OR UPPER(REPLACE(Home, ' ', ''))like Upper(@Home) + '%' )
AND (@Corp IS NULL OR UPPER(REPLACE(Corp, ' ', '')) like Upper(@Corp) + '%' )

AND (@id_City IS NULL OR D.id_City = @id_City OR Ct.PID = @id_City)
AND (@id_EQ IS NULL OR A.id_EQ = @id_EQ )
AND (@id_User IS NULL OR A.id_User = @id_User )
AND (  (A.DateCreate > @DateFrom OR @DateFrom IS NULL) AND (A.DateCreate <= @DateTo OR @DateTo IS NULL))
AND (@DeptNew IS NULL OR datediff(mm, ISNULL(LPD, StartDate), @CurDate ) = @DeptNew)
order by A.FIO

--select @Podd

UPDATE #T_R SET StartDate = coalesce(LPD, StartDate, DateOpen) WHERE StartDate IS NULL

select id_City, id_HomeType, id_EQ, Price 
INTO #NeedPay
FROM Dic_EQPrice D (NOLOCK)
WHERE DateFrom = (SELECT MAX(DateFrom)
  FROM Dic_EQPrice PPP (NOLOCK) 
  WHERE (PPP.id_HomeType = D.id_HomeType OR PPP.id_HomeType IS NULL)
       AND (PPP.id_City = D.id_City OR PPP.id_City IS NULL)
       AND (PPP.id_EQ = D.id_EQ OR PPP.id_EQ IS NULL)
)


UPDATE #T_R SET NeedPay = (SELECT max(Price) FROM #NeedPay D
  WHERE (#T_R.id_HomeType = D.id_HomeType OR D.id_HomeType IS NULL)
       AND (#T_R.id_City = D.id_City OR D.id_City IS NULL)
       AND (#T_R.id_EQ = D.id_EQ OR D.id_EQ IS NULL)

)

UPDATE #T_R SET DeptSum_CUR = isnull(NeedPay, 0)*DeptNew + isnull(DeptSum, 0) - 
  case when isnull(DeptSum, 0) > 0 then isnull(NeedPay, 0) else 0 end



IF not @DeptM  is null
  delete from #T_R
  WHERE not ((@DeptM IS NULL AND @DeptM2 IS NULL) OR (DeptNew >= @DeptM AND DeptNew <= @DeptM2)) OR DeptNew IS NULL

IF not @DeptSumm  is null
  delete from #T_R
  WHERE not ((@DeptSumm IS NULL AND @DeptSumm2 IS NULL) OR (DeptSum_CUR >= @DeptSumm AND DeptSum_CUR <= @DeptSumm2))
  OR DeptSum_CUR IS NULL OR DeptSum_CUR <= 0


SET NOCOUNT OFF

SELECT * FROM #T_R (NOLOCK) WHERE 
((Dept_CNT > 0 and @id_Grp = -666)  OR @id_Grp IS NULL)
OR ((Dept_CNT = 0 AND @id_Grp = -1013)  OR @id_Grp IS NULL) 
OR (@id_Grp = -1024 and (LPD < @CurDate OR Dept_CNT > 0))
OR (@id_Grp = -1025 and LPD >= @CurDate AND Dept_CNT = 0)

OR (@id_Grp > -100)
OR (@id_User > 0)
OR ((@DeptM IS NULL AND @DeptM2 IS NULL) OR (DeptNew >= @DeptM AND DeptNew <= @DeptM2))
--OR ((@DeptSumm IS NULL AND @DeptSumm2 IS NULL) OR (DeptSum_CUR > @DeptSumm AND DeptSum_CUR < @DeptSumm2))
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

