alter table Dic_EQ add OrderID int


go

CREATE TABLE [AB_Period] (
	[id_P] [int] IDENTITY (1, 1) NOT NULL ,
	[id_Abon] [int] NOT NULL ,
	[P_Year] [int] NOT NULL ,
	[P_Month] [int] NOT NULL ,
	[P_DDD] [datetime] NULL ,
	[id_EQ] [int] NULL ,
	[EQName] [varchar] (255) COLLATE Cyrillic_General_CI_AS NULL ,
	[Tariff] [money] NULL ,
	[Tariff_real] [money] NULL ,
	[FullPayDate] [datetime] NULL ,
	[Total] [money] NULL ,
	[cmnt] [varchar] (255) COLLATE Cyrillic_General_CI_AS NULL 
) ON [PRIMARY]
GO


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AB_PM_UNCalc_GetList]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AB_PM_UNCalc_GetList]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AB_PM_UNCalc_v2]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AB_PM_UNCalc_v2]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



CREATE PROCEDURE AB_PM_UNCalc_GetList
  @id_Abon INT = NULL
 AS

DECLARE @DateStart DATETIME 

SELECT @DateStart=min(COALESCE(StartDate, DateOpen)) 
FROM Doc_Doc D (NOLOCK)
JOIN AB_Abon A (NOLOCK) ON A.id_Doc = D.id_DOc
WHERE @id_Abon = id_Abon

select P_Year, P_Month, P_DDD, EQName, Tariff, Tariff_real, FullPayDate, cmnt, NULL AS id_PM, 1 as XXX
from AB_Period (NOLOCK) where id_Abon = @id_Abon 

UNION ALL

SELECT Null, Null, COALESCE(PayDate, @DateStart, DateCreate) as P_DD, Null, Summ, Null, COALESCE(PayDate, @DateStart, DateCreate), PMComment, id_PM, 0 as XXX 
FROM AB_PM (NOLOCK) where id_Abon = @id_Abon and deleted=0
ORDER BY P_DDD DESC, XXX

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE AB_PM_UNCalc_v2 
  @id_Abon INT = NULL
 AS


SET NOCOUNT ON

insert into _LOG(MMM) VALUES('������') 

CREATE TABLE #Period (
	[id_P] [int] IDENTITY (1, 1) ,
	[P_Year] [int] NOT NULL ,
	[P_Month] [int] NOT NULL ,
	[P_DDD] [DATETIME] NULL ,
        id_EQ [int],
        EQName VARCHAR(255), 
	[Tariff] [money] NULL ,
        [Tariff_real] [money] NULL ,

	[FullPayDate] [DATETIME] NULL ,
	[Total] [money] NULL,
        cmnt varchar(255)
) 


DECLARE @I INT, @N INT, @id_EQ INT, @id_City INT, @id_HomeType INT, @DateStart DATETIME

INSERT INTO #Period(P_Year, P_Month) EXEC AA_MonthList @id_Abon 
UPDATE #Period SET id_EQ = @id_EQ, P_DDD = CAST(CAST(P_Year as VARCHAR) + '.' + CAST(P_Month as VARCHAR) + '.01' as DateTime)



SELECT @N = MAX(id_P), @DateStart = min(P_DDD) FROM #Period (NOLOCK)

SELECT @id_EQ = id_EQ, @id_City = id_City , @id_HomeType = id_HomeType
FROM Doc_Doc D (NOLOCK)
JOIN AB_Abon A (NOLOCK) ON A.id_Doc = D.id_DOc
WHERE id_Abon = @id_Abon

--SELECT * INTO #TMP_EQ_Hst FROM AB_EQ EQ (NOLOCK) WHERE id_Abon = @id_Abon

SELECT *, CAST(Null as DateTime) as DateTo INTO #TMP_EQPrice 
FROM Dic_EQPrice (NOLOCK) 
WHERE (id_EQ = @id_EQ OR id_EQ IN (SELECT id_EQ FROM #TMP_EQ_Hst (NOLOCK))) 
and @id_City = id_City AND (@id_HomeType = id_HomeType OR id_HomeType IS NULL)
ORDER BY DateFrom

select @id_City, @id_HomeType, @id_EQ, * from #TMP_EQ_Hst

UPDATE #TMP_EQPrice SET DateTo = isnull((SELECT MAX(DateFrom) FROM #TMP_EQPrice Z WHERE Z.id_EQ=#TMP_EQPrice.id_EQ AND Z.id_EQPrice<>#TMP_EQPrice.id_EQPrice AND Z.DateFrom>#TMP_EQPrice.DateFrom) - 1, Getdate()+3650)

--select * from #Period
--select @id_EQ, @id_City, @id_HomeType  
--select * from #TMP_EQ_Hst
--select * from #TMP_EQPrice


UPDATE #Period SET id_EQ = COALESCE(
(SELECT MAX(id_EQ) FROM #TMP_EQ_Hst H WHERE DateFromEQ =(SELECT MAX(DateFromEQ) FROM #TMP_EQ_Hst H WHERE DateFromEQ <= P_DDD))
, @id_EQ)

UPDATE #Period SET Tariff = 
(SELECT MAX(Price) FROM #TMP_EQPrice Z WHERE DateFrom =(SELECT MAX(DateFrom) FROM #TMP_EQPrice H WHERE DateFrom <= P_DDD AND #Period.id_EQ=H.id_EQ AND Z.id_EQ=H.id_EQ))

UPDATE #Period SET EQName = (SELECT MAX(Name) FROm DIC_EQ E WHERE E.id_EQ=#Period.id_EQ),
  Total = (select sum(isnull(Tariff, 0)) from #Period Z WHERE Z.id_P <= #Period.id_P)  


SELECT IDENTITY (INT) as ID, 
PDate = COALESCE(PayDate, @DateStart, DateCreate), sum(Summ) as Summ, CAST(Null as DateTime) AS PM_DDD 
INTO #PM
FROM AB_PM (NOLOCK) 
WHERE id_Abon=@id_Abon and deleted=0
GROUP BY COALESCE(PayDate, @DateStart, DateCreate)
ORDER BY COALESCE(PayDate, @DateStart, DateCreate)

UPDATE #PM SET PM_DDD = CAST(CAST(Year(PDate) as VARCHAR) + '.' + CAST(Month(PDate) as VARCHAR) + '.01' as DateTime)

--select *, @DateStart from #PM

DECLARE @Tariff MONEY, @Tariff_OLD MONEY, @Tariff_real MONEY, @SUMM MONEY, @P_DDD DATETIME, @ID INT, @MAX_ID INT, @PDate DATETIME
SELECT @i = 1, @ID = 1
SELECT @MAX_ID = MAX(ID) FROM #PM
--select @ID, @MAX_ID, @i, @N
WHILE @ID <= @MAX_ID
BEGIN

  WHILE @i <= @N
  BEGIN
    SELECT @SUMM = sum(Summ), @PDate = max(CASE WHEN Summ > 0 THEN PDate ELSE NULL END) FROM #PM WHERE (ID <= @ID AND Summ > 0) OR (Summ < 0)

    SELECT @id_EQ=id_EQ, @Tariff = ISNULL(Tariff_real, Tariff), @P_DDD = P_DDD FROM #Period WHERE id_P = @i
    SELECT @Tariff_real = MAX(Price) FROM #TMP_EQPrice WHERE id_EQ = @id_EQ AND DateFrom <= @PDate AND DateTo >= @PDate
   -- select @Tariff_real, @SUMM
    IF @Tariff_real <= @SUMM 
    BEGIN
      UPDATE #Period SET FullPayDate = @PDate, Tariff_real = @Tariff_real WHERE id_P = @i
      INSERT INTO #PM(Summ, PDate) VALUES(-1 * @Tariff, @P_DDD)
     -- UPDATE #Period SET cmnt = 'sss'  WHERE id_P = @i 
      SET @i = @i + 1
    END
    ELSE
    BEGIN
      BREAK
    END
  END
  SET @ID = @ID + 1
END



--SELECT * FROM #PM
DELETE FROM #Period WHERE P_DDD > Getdate() AND FullPayDate IS NULL
UPDATE #Period SET Tariff_real = (SELECT MAX(Price) FROM #TMP_EQPrice Z WHERE #Period.id_EQ=Z.id_EQ AND DateFrom <= Getdate() AND DateTo >= Getdate())
WHERE FullPayDate IS NULL


DELETE FROM AB_Period WHERE id_Abon=@id_Abon

INSERT INTO AB_Period(id_Abon, P_Year, P_Month, P_DDD, id_EQ, EQName, Tariff, Tariff_real, FullPayDate, Total, cmnt)
SELECT @id_Abon, P_Year, P_Month, P_DDD, id_EQ, EQName, Tariff, Tariff_real, FullPayDate, Total, cmnt FROM #Period (NOLOCK)

SELECT * FROM AB_Period (NOLOCK) WHERE id_Abon=@id_Abon ORDER BY P_DDD DESC






GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



