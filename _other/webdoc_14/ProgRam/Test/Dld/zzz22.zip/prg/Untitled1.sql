exec AB_PM_UNCalc_v2 394807

exec AB_PM_UNCalc_GetList 394807


select * from ab_PM where id_Abon=394807

select * from Dic_EQPrice where id_City=17 and id_HomeType=3

659

SELECT *  FROM AB_EQ EQ (NOLOCK) WHERE id_Abon = 394807
SELECT *  FROM AB_Abon EQ (NOLOCK) WHERE id_Abon = 394807

SELECT *, CAST(Null as DateTime) as DateTo  
FROM Dic_EQPrice (NOLOCK) 
WHERE (id_EQ = 650 OR id_EQ IN (641, 650)) 
and 17 = id_City AND (3 = id_HomeType OR id_HomeType IS NULL)



