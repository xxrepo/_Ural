if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AA_MonthList]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AA_MonthList]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AB_AbonGetList]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AB_AbonGetList]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AB_PM_UNCalc_v2]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AB_PM_UNCalc_v2]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE AA_MonthList
  @id_Abon INT = -1
AS

DECLARE @D_Doc DATETIME, @Date2 DATETIME

SELECT @D_Doc=min(COALESCE(StartDate, DateOpen)) 
FROM Doc_Doc D (NOLOCK)
JOIN AB_Abon A (NOLOCK) ON A.id_Doc = D.id_DOc
WHERE @id_Abon = -1 OR @id_Abon = id_Abon

SET @D_Doc = CAST(CAST(Year(@D_Doc) as VARCHAR) + '.' + CAST(Month(@D_Doc) as VARCHAR) + '.1' as DateTime) 


SET @Date2 = DATEADD(yyyy, 3, getdate())  
SET @Date2 = CAST(CAST(Year(@Date2) as VARCHAR) + '.' + CAST(Month(@Date2) as VARCHAR) + '.1' as DateTime) 

CREATE TABLE #T([P_Year] [int] NOT NULL ,P_Month [int] NOT NULL )

-- SELECT @D_Doc, @Date2

WHILE @D_Doc <= @Date2
BEGIN
  INSERT INTO #T(P_Year, P_Month) VALUES(Year(@D_Doc), Month(@D_Doc))
  SET @D_Doc = DATEADD(mm, 1, @D_Doc) 
END

SELECT * FROM #T (NOLOCK) ORDER BY P_Year, P_Month
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO








CREATE PROCEDURE AB_AbonGetList
  @id_Doc INT = null,
  @id_Grp INT = null,
  @id_EQ INT = null,
  @id_City INT = null,
  @FIO VARCHAR(255) = null,
  @Street VARCHAR(255) = null,
  @DocNum VARCHAR(255) = null,
  @FlatNum INT = NULL,
  @Home VARCHAR(10) = NULL ,
  @Corp  VARCHAR(10) = NULL,
  @id_User INT = NULL,
  @DateFrom DATETIME = NULL,
  @DateTo DATETIME = NULL,
  @LetterIndex VARCHAR(10) = NULL,
  @DeptNew INT = NULL,
  @Podd VARCHAR(10) = NULL,
  @DeptM INTEGER = NULL,
  @DeptM2 INTEGER = NULL,
  @DeptSumm money = NULL,
  @DeptSumm2 money = NULL
 AS

SET NOCOUNT ON

--select * from Doc_Doc where (@Podd IS NULL OR  Upper(@Podd) =  Upper(Podd))

-- select  @Home  = NULL ,  @Corp  = NULL

DECLARE @CurDate DATETIME

SET @CurDate = CAST(CAST(Year(getdate()) as VARCHAR) + '.' + CAST(Month(getdate()) as VARCHAR) + '.1' as DateTime)

SELECT A.*, DocNum,
DateOpen,
DateClose,
D.id_City,
Street,
Home,
Corp,
Podd,
MNG_Name,
MNG_Cnt,
D.id_HomeType,
DocComment,  dbo.FormatInt(DocNum, 4) + dbo.FormatInt(FlatNum, 3) + ISNULL(LetterIndex, '') AS DN, EQ.Name as EQName, 
HT.Name as HTName, ISNULL( CP.Name + '/', '') + Ct.Name as CityName,
CP.Name as CityName1, Ct.Name as CityName2,
Dept_CNT = (SELECT count(DP.id_ABon) FROM AB_Dept_Period DP (NOLOCK) WHERE 1=0 and DP.id_Abon = A.id_Abon),
DeptNew = datediff(mm, coalesce(LPD, StartDate, DateOpen), @CurDate ) -- CASE WHEN LPD < @CurDate OR LPD IS NULL THEN 1 ELSE 0 END
, NeedPay = cast(null as money) 
, DeptSum_CUR = cast(null as money) 
INTO #T_R
from AB_Abon A (NOLOCK) 
JOIN Doc_Doc D (NOLOCK) On D.id_Doc = A.id_Doc
JOIN Dic_City Ct (NOLOCK) On Ct.id_City = D.id_City
LEFT JOIN Dic_City CP (NOLOCK) ON CP.id_City = Ct.PID
LEFT JOIN Dic_EQ EQ (NOLOCK) On EQ.id_EQ = A.id_EQ
LEFT JOIN Dic_HomeType HT (NOLOCK) On HT.id_HomeType = D.id_HomeType
where (A.deleted=0 OR @id_Grp < 0) AND 
(@id_Grp IS NULL OR  @id_Grp = -666  OR  @id_Grp = -1013  OR  @id_Grp = -1024  OR  @id_Grp = -1025  
OR (@id_Grp = -13 and A.deleted = 1)
OR (@id_Grp = -26 and A.deleted = 0)


) AND
(Upper(Street) like '%' + Upper(@Street) + '%' OR @Street IS NULL) AND 
(@DocNum IS NULL 
OR (dbo.FormatInt(DocNum, 4) + dbo.FormatInt(FlatNum, 3) + ISNULL(LetterIndex, '') like '0' + @DocNum + '%' )
OR (dbo.FormatInt(DocNum, 4) + dbo.FormatInt(FlatNum, 3) + ISNULL(LetterIndex, '') like '' + @DocNum + '%' )  )
AND (@FlatNum IS NULL OR FlatNum = @FlatNum )
AND (Upper(FIO) like '%' + Upper(@FIO) + '%' OR @FIO IS NULL)  
AND (Upper(LetterIndex) like '%' + Upper(@LetterIndex) + '%' OR @LetterIndex IS NULL)  
AND (@id_Doc IS NULL OR A.id_Doc = @id_Doc )
AND (@Podd IS NULL OR  Upper(@Podd) =  Upper(Podd))
AND (@Home IS NULL OR Upper(Home) = Upper(@Home))
AND (@Corp IS NULL OR Upper(Corp) = Upper(@Corp) )
AND (@id_City IS NULL OR D.id_City = @id_City OR Ct.PID = @id_City)
AND (@id_EQ IS NULL OR A.id_EQ = @id_EQ )
AND (@id_User IS NULL OR A.id_User = @id_User )
AND (  (A.DateCreate > @DateFrom OR @DateFrom IS NULL) AND (A.DateCreate <= @DateTo OR @DateTo IS NULL))
AND (@DeptNew IS NULL OR datediff(mm, ISNULL(LPD, StartDate), @CurDate ) = @DeptNew)
order by A.FIO

--select @Podd

UPDATE #T_R SET StartDate = coalesce(LPD, StartDate, DateOpen) WHERE StartDate IS NULL

select id_City, id_HomeType, id_EQ, Price 
INTO #NeedPay
FROM Dic_EQPrice D (NOLOCK)
WHERE DateFrom = (SELECT MAX(DateFrom)
  FROM Dic_EQPrice PPP (NOLOCK) 
  WHERE (PPP.id_HomeType = D.id_HomeType OR PPP.id_HomeType IS NULL)
       AND (PPP.id_City = D.id_City OR PPP.id_City IS NULL)
       AND (PPP.id_EQ = D.id_EQ OR PPP.id_EQ IS NULL)
)


UPDATE #T_R SET NeedPay = (SELECT max(Price) FROM #NeedPay D
  WHERE (#T_R.id_HomeType = D.id_HomeType OR D.id_HomeType IS NULL)
       AND (#T_R.id_City = D.id_City OR D.id_City IS NULL)
       AND (#T_R.id_EQ = D.id_EQ OR D.id_EQ IS NULL)

)

UPDATE #T_R SET DeptSum_CUR = isnull(NeedPay, 0)*DeptNew + isnull(DeptSum, 0) - 
  case when isnull(DeptSum, 0) > 0 then isnull(NeedPay, 0) else 0 end

--select @DeptM,@DeptM2, * from #T_R

--select @DeptM,@DeptM2, * from #T_R
--WHERE ((DeptNew >= @DeptM AND DeptNew <= @DeptM2))

IF not @DeptM  is null
  delete from #T_R
  WHERE not ((@DeptM IS NULL AND @DeptM2 IS NULL) OR (DeptNew >= @DeptM AND DeptNew <= @DeptM2)) OR DeptNew IS NULL

IF not @DeptSumm  is null
  delete from #T_R
  WHERE not ((@DeptSumm IS NULL AND @DeptSumm2 IS NULL) OR (DeptSum_CUR >= @DeptSumm AND DeptSum_CUR <= @DeptSumm2))
  OR DeptSum_CUR IS NULL OR DeptSum_CUR <= 0


SET NOCOUNT OFF

SELECT * FROM #T_R (NOLOCK) WHERE 
((Dept_CNT > 0 and @id_Grp = -666)  OR @id_Grp IS NULL)
OR ((Dept_CNT = 0 AND @id_Grp = -1013)  OR @id_Grp IS NULL) 
OR (@id_Grp = -1024 and (LPD < @CurDate OR Dept_CNT > 0))
OR (@id_Grp = -1025 and LPD >= @CurDate AND Dept_CNT = 0)

OR (@id_Grp > -100)
OR (@id_User > 0)
OR ((@DeptM IS NULL AND @DeptM2 IS NULL) OR (DeptNew >= @DeptM AND DeptNew <= @DeptM2))
--OR ((@DeptSumm IS NULL AND @DeptSumm2 IS NULL) OR (DeptSum_CUR > @DeptSumm AND DeptSum_CUR < @DeptSumm2))
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE AB_PM_UNCalc_v2
  @id_Abon INT = NULL
 AS


SET NOCOUNT ON

insert into _LOG(MMM) VALUES('������') 


-- ������ ������� ������� --
CREATE TABLE #Period (
	[id_P] [int] IDENTITY (1, 1) ,
	[P_Year] [int] NOT NULL ,
	[P_Month] [int] NOT NULL ,
        id_EQ [int],
	[Tariff] [money] NULL ,
        [Tariff_real] [money] NULL ,

	[Total] [money] NULL
) 

INSERT INTO #Period(P_Year, P_Month) EXEC AA_MonthList @id_Abon 

DECLARE @I INT, @N INT, @id_EQ INT, @id_City INT, @id_HomeType INT

SELECT @N = MAX(id_P) FROM #Period (NOLOCK)

SELECT @id_EQ = id_EQ, @id_City = id_City , @id_HomeType = id_HomeType
FROM Doc_Doc D (NOLOCK)
JOIN AB_Abon A (NOLOCK) ON A.id_Doc = D.id_DOc
WHERE id_Abon = @id_Abon

SELECT * INTO #TMP_EQ_Hst FROM AB_EQ EQ (NOLOCK) WHERE id_Abon = @id_Abon

SELECT * INTO #TMP_EQPrice 
FROM Dic_EQPrice (NOLOCK) 
WHERE id_EQ IN (SELECT id_EQ FROM #TMP_EQ_Hst (NOLOCK)) and @id_City = id_City AND (@id_HomeType = id_HomeType OR id_HomeType IS NULL)
ORDER BY DateFrom

--select * from #Period
select @id_EQ
select * from #TMP_EQ_Hst
select * from #TMP_EQPrice

/*
SET @PD = CAST(CAST(Year(@PD) as VARCHAR) + '.' + CAST(Month(@PD) as VARCHAR) + '.28' as DateTime)
IF @id_Abon is null SET @PD = NULL

IF isnull(@OrdStr, '') = '1313' 
BEGIN

insert into _LOG(MMM) VALUES('T���� - 1313')  
  delete from _XXX_T_PER
  UPDATE AB_PM_PERIOD SET NeedPay = Null

  UPDATE AB_PM SET Summ = 1000
insert into _LOG(MMM) VALUES('T���� - ��--���')  
END


DECLARE @SGNM INT

SET @SGNM = SIGN(@id_Abon)
SET @id_Abon = ABS(@id_Abon)

CREATE TABLE #T_AB (LPD2 DATETIME, id_City INT, id_Abon INT, id_EQ INT, id_HomeType INT, DateOpen DATETIME, StartDate DATETIME, MaxPayDate DATETIME, CurTariff money, CurTariff2 money)
CREATE TABLE #T_PER (ID_XXX INT IDENTITY(1, 1), id_City INT, id_Abon INT, id_EQ INT, id_HomeType INT, P_Year INT, P_Month INT, NeedPay  money, NeedPay2  money, Total money, Payed money, Delta money, DDD DATETIME, Closed BIT default 0, DateOpen DATETIME, StartDate DATETIME, MaxPayDate DATETIME)


INSERT INTO #T_AB(LPD2, id_City, id_Abon, id_EQ, id_HomeType, DateOpen, StartDate, CurTariff, CurTariff2)
SELECT LPD, D.id_City, id_Abon, id_EQ, id_HomeType, DateOpen, StartDate, 
CurTariff = (
SELECT MAX(Price) 
FROM Dic_EQPrice EQP (NOLOCK) 
WHERE DateFrom = (
  SELECT MAX(DateFrom) 
  FROM Dic_EQPrice PPP (NOLOCK) 
  WHERE (PPP.id_HomeType = D.id_HomeType OR PPP.id_HomeType IS NULL)
       AND (PPP.id_City = D.id_City OR PPP.id_City IS NULL)
       AND (PPP.id_EQ = A.id_EQ OR PPP.id_EQ IS NULL)
  AND DateFrom <= CAST(CAST(Year(getdate()) as VARCHAR) + '.' + CAST(Month(getdate()) as VARCHAR) + '.1' as DateTime)
  AND (@PD IS NULL OR @PD >= DateFrom) -- 1013
)
  AND (EQP.id_HomeType = D.id_HomeType OR EQP.id_HomeType IS NULL) 
  AND (EQP.id_City = D.id_City OR EQP.id_City IS NULL)
  AND (A.id_EQ = EQP.id_EQ OR EQP.id_EQ IS NULL)

)
,
CurTariff2 = (
SELECT MAX(Price) 
FROM Dic_EQPrice EQP (NOLOCK) 
WHERE DateFrom = (
  SELECT MAX(DateFrom) 
  FROM Dic_EQPrice PPP (NOLOCK) 
  WHERE (PPP.id_HomeType = D.id_HomeType)
       AND (PPP.id_City = D.id_City OR PPP.id_City IS NULL)
       AND (PPP.id_EQ = A.id_EQ OR PPP.id_EQ IS NULL)
  AND DateFrom <= CAST(CAST(Year(getdate()) as VARCHAR) + '.' + CAST(Month(getdate()) as VARCHAR) + '.1' as DateTime)
  AND (@PD IS NULL OR @PD >= DateFrom) -- 1013
)
  AND (EQP.id_HomeType = D.id_HomeType) 
  AND (EQP.id_City = D.id_City OR EQP.id_City IS NULL)
  AND (A.id_EQ = EQP.id_EQ OR EQP.id_EQ IS NULL)

)
from AB_Abon A (NOLOCK)
JOIN Doc_Doc D (NOLOCK) ON D.id_Doc = A.id_Doc
JOIN Dic_City Ct (NOLOCK) On Ct.id_City = D.id_City
where A.deleted=0 AND (D.id_City = @id_City  OR @id_City IS NULL OR Ct.PID = @id_City)
 AND (id_Abon = @id_Abon OR ISNULL(@id_Abon, -13) = -13)
AND (D.id_Doc = @id_Doc OR @id_Doc IS NULL)
AND (A.id_EQ = @id_EQ OR @id_EQ IS NULL)

UPDATE #T_AB SET CurTariff = CurTariff2 WHERE CurTariff2 IS NOT NULL

insert into _LOG(MMM) VALUES('��-�� �������')  

  DECLARE @DX DATETIME

IF @OrdStr = '1013' and @Sign = 0 
BEGIN
  SET @DX = CAST(CAST(Year(getdate()) as VARCHAR) + '.' + CAST(Month(getdate()) as VARCHAR) + '.1' as DateTime)
 
  DELETE FROM #T_AB WHERE LPD2 < @DX OR LPD2 IS NULL
END
IF @OrdStr = '1013' and @Sign = 1 
BEGIN
  SET @DX = CAST(CAST(Year(getdate()) as VARCHAR) + '.' + CAST(Month(getdate()) as VARCHAR) + '.1' as DateTime)
 
  DELETE FROM #T_AB WHERE LPD2 >= @DX
END

insert into _LOG(MMM) VALUES('��-�� ������� ���--��')  
--select @Sign
--select COUNT(*) from #T_AB return

if @OrdStr = '*' 
BEGIN
--return

  INSERT INTO #T_PER(DDD, id_City, id_EQ, id_HomeType, id_Abon, P_Year, P_Month, NeedPay, Total, Payed, Delta)
  SELECT CAST(CAST(P_Year as VARCHAR) + '.' + CAST(P_Month as VARCHAR) + '.1' as DateTime) AS DDD,
    A.id_City, id_EQ, id_HomeType, A.id_Abon, P_Year, P_Month, NeedPay, Total, Payed, Delta
  FROM #T_AB A (NOLOCK)
  JOIN _XXX_T_PER RRR (NOLOCK) ON RRR.id_Abon = A.id_Abon



SELECT ID_XXX, A.id_Doc, P.id_Abon, 
DDD,
A.FIO, 
A.Cnt, AbonComment, Ct.Name AS CityName, Street, Home, Corp, Podd, FlatNum, 
dbo.FormatInt(DocNum, 4) + dbo.FormatInt(FlatNum, 3) + ISNULL(LetterIndex, '') AS DN, EQ.Name as EQName, 
HT.Name as HTName, 
NeedPay, Total, Payed, Delta, Closed , D.DateOpen
INTO #REZZZ
FROM #T_PER P (NOLOCK) 
JOIN AB_Abon A (NOLOCK) ON A.id_Abon = P.id_Abon
JOIN Doc_Doc D (NOLOCK) On D.id_Doc = A.id_Doc
JOIN Dic_City Ct (NOLOCK) On Ct.id_City = D.id_City
LEFT JOIN Dic_EQ EQ (NOLOCK) On EQ.id_EQ = P.id_EQ
LEFT JOIN Dic_HomeType HT (NOLOCK) On HT.id_HomeType = D.id_HomeType
WHERE (DDD >= @DateFrom OR @DateFrom IS NULL)
--AND  DDD < GETDATE() 
AND  (
(@Sign = 0 AND Delta = 0) OR (@Sign * ISNULL(Delta, 0) > 0 ) OR @Sign IS NULL
)
ORDER BY A.FIO, DDD DESC


  SELECT AP.id_Abon, ADate AS DDD
  INTO #OLD
  from AB_Dept_Period AP (NOLOCK)
  LEFT JOIN #REZZZ R (NOLOCK) ON R.id_Abon = AP.id_Abon AND R.DDD = AP.ADate
  WHERE R.id_Abon IS NULL and 1=0

  INSERT INTO #REZZZ(ID_XXX, id_Doc, id_Abon, DDD, FIO, Cnt, AbonComment, CityName,
  Street, Home, Corp, Podd, FlatNum,DN, EQName, HTName, DateOpen)
  SELECT ID_XXX = -1, A.id_Doc, P.id_Abon, 
  DDD,
  A.FIO, 
  A.Cnt, AbonComment, Ct.Name AS CityName, Street, Home, Corp, Podd, FlatNum,  
  dbo.FormatInt(DocNum, 4) + dbo.FormatInt(FlatNum, 3) + ISNULL(LetterIndex, '') AS DN, EQ.Name as EQName, 
  HT.Name as HTName, 
  D.DateOpen
  FROM #OLD P (NOLOCK) 
  JOIN AB_Abon A (NOLOCK) ON A.id_Abon = P.id_Abon
  JOIN Doc_Doc D (NOLOCK) On D.id_Doc = A.id_Doc
  JOIN Dic_City Ct (NOLOCK) On Ct.id_City = D.id_City
  LEFT JOIN Dic_EQ EQ (NOLOCK) On EQ.id_EQ = A.id_EQ
  LEFT JOIN Dic_HomeType HT (NOLOCK) On HT.id_HomeType = D.id_HomeType
  ORDER BY A.FIO, DDD DESC

  SELECT P.id_Abon 
  INTO #DeptAb
  FROM #REZZZ P
  GROUP BY P.id_Abon 

  SELECT A.id_Doc, COUNT(*) AS DOC_AB_COUNT
  INTO #D_CNT
  FROM AB_Abon A (NOLOCK)
  GROUP BY A.id_Doc

  SELECT D.id_Doc, CT.NAme AS CityName, D.Street, D.Home, D.Corp, D.Podd, FlatNum = -1, 
   Count_Suxxx = COUNT(DISTINCT A.id_Abon), Count_Total = MAX(D_CNT.DOC_AB_COUNT), 
D.MNG_Name, MNG_Cnt, MIN(DocComment) AS DocComment
, MIN(DocNum) AS DocNum
  FROM #DeptAb R(NOLOCK)
  JOIN AB_ABon A (NOLOCK) On R.id_Abon = A.id_Abon
   JOIN Doc_Doc D (NOLOCK) On D.id_Doc = A.id_Doc
  JOIN Dic_City Ct (NOLOCK) On Ct.id_City = D.id_City
  JOIN #D_CNT D_CNT (NOLOCK) On D_CNT.id_Doc = D.id_Doc
  GROUP BY D.id_Doc, CT.NAme, D.Street, D.Home, D.Corp, D.Podd, 
  D.MNG_Name, MNG_Cnt

  RETURN
END

--select * from #T_PER return

IF isnull(@OrdStr, '') = '1013' --OR @OrdStr = 'DDD'
BEGIN
--select @Dateto
  INSERT INTO #T_PER(DDD, id_City, id_EQ, id_HomeType, id_Abon, P_Year, P_Month, NeedPay, Total, Payed, Delta)
  SELECT CAST(CAST(P_Year as VARCHAR) + '.' + CAST(P_Month as VARCHAR) + '.1' as DateTime) AS DDD,
    A.id_City, id_EQ2, id_HomeType, A.id_Abon, P_Year, P_Month, NeedPay, Total, Payed, Delta
  FROM #T_AB A (NOLOCK)
  JOIN _XXX_T_PER RRR (NOLOCK) ON RRR.id_Abon = A.id_Abon
  
DECLARE @DateTo13 DATETIME, @D13 DATETIME
DECLARE @NeedPay13 MONEY, @Total13 MONEY, @Payed13 MONEY, @Delta13 MONEY

SELECT @D13 = max(DDD) FROM #T_PER (NOLOCK)
SELECT @DateTo13 = CAST(CAST(Year(getdate()) as VARCHAR) + '.' + CAST(MONTH(getdate()) as VARCHAR) + '.1' as DateTime)

if isnull(@ID_aBON, 0) <> 0 
  delete from #T_PER where DDD > @DateTo13
--select @DateTo13, getdate()

SELECT @NeedPay13 = NeedPay, @Total13 = Total, @Payed13 = Payed, @Delta13 = NeedPay --Delta
from #T_PER  (NOLOCK) WHERE DDD = @D13


--SELECT @D13, @DateTo13

--select * from #T_AB

WHILE @D13 < @DateTo13 --and 1=2
BEGIN
  SELECT @D13 = DATEADD(Month, 1, @D13), @Total13 = @Total13 + @NeedPay13--, @Delta13 = @Delta13 + @NeedPay13
  
  INSERT INTO #T_PER(DDD, id_City, id_EQ, id_HomeType, id_Abon, P_Year, P_Month, NeedPay, Total, Payed, Delta)
  SELECT @D13 AS DDD,
    A.id_City, id_EQ, id_HomeType, A.id_Abon, Year(@D13), Month(@D13), @NeedPay13, @Total13, @Payed13, @Delta13
  FROM #T_AB A (NOLOCK)


END

--select @SGNM
 --select 1, * from #T_PER order by DDD return

if @SGNM < 0
BEGIN
 -- select * from #T_PER
 -- select 111
  SELECT ID_XXX = -1, id_Doc= -1, id_Abon, DDD = CAST(NULL AS DATETIME), FIO = CAST(NULL AS VARCHAR(255)), 
    Cnt = CAST(NULL AS VARCHAR(255)), AbonComment = CAST(NULL AS VARCHAR(255)), 
CityName = CAST(NULL AS VARCHAR(255)), Street = CAST(NULL AS VARCHAR(255)), 
Home= -1, Corp= -1, Podd= -1, FlatNum= -1, DN= -1,  EQName = CAST(NULL AS VARCHAR(10)), 
    HTName = CAST(NULL AS VARCHAR(10)), 
    NeedPay = CAST(Null AS money), Total = CAST(Null AS money), Payed = CAST(Null AS money), Delta = SUM(Delta), Closed = CAST(NULL AS DATETIME) , DateOpen = CAST(NULL AS DATETIME)
  FROM #T_PER (NOLOCK)
  GROUP BY id_Abon

  RETURN
END

set @DateTo = @DX

--select @DateFrom, @DateTo


SELECT ID_XXX, A.id_Doc, P.id_Abon, 
DDD,
A.FIO, 
A.Cnt, AbonComment, Ct.Name AS CityName, Street, Home, Corp, Podd, FlatNum, 
dbo.FormatInt(DocNum, 4) + dbo.FormatInt(FlatNum, 3) + ISNULL(LetterIndex, '') AS DN, EQ.Name as EQName, 
HT.Name as HTName, 
NeedPay, Total, Payed, Delta, Closed , D.DateOpen
FROM #T_PER P (NOLOCK) 
JOIN AB_Abon A (NOLOCK) ON A.id_Abon = P.id_Abon
JOIN Doc_Doc D (NOLOCK) On D.id_Doc = A.id_Doc
JOIN Dic_City Ct (NOLOCK) On Ct.id_City = D.id_City
LEFT JOIN Dic_EQ EQ (NOLOCK) On EQ.id_EQ = P.id_EQ
LEFT JOIN Dic_HomeType HT (NOLOCK) On HT.id_HomeType = D.id_HomeType
WHERE (DDD >= @DateFrom OR @DateFrom IS NULL)
AND (DDD < @DateTo OR @DateTo IS NULL)

--AND  ((@Sign = 0 AND Delta = 0) OR (@Sign * ISNULL(Delta, 0) > 0 ) OR @Sign IS NULL)
AND ((@Sign = 0 AND Delta = 0) OR (@Sign * Sign(ISNULL(Delta, 0)) > 0) OR @Sign IS NULL)
--AND P.Delta > 0
ORDER BY A.FIO, P.id_Abon, DDD 


return
END

SELECT EQ.id_Abon, 
(SELECT max(EQ2.DateFromEQ) FROM  AB_EQ EQ2 (NOLOCK) WHERE EQ2.id_Abon = EQ.id_Abon AND EQ2.DateFromEQ < EQ.DateFromEQ)
AS DFrom,
EQ.DateFromEQ AS DTo, EQ.id_EQ
iNTO #EQH
FROM AB_EQ EQ (NOLOCK)
JOIN #T_AB A (NOLOCK) ON A.id_Abon = EQ.id_Abon
ORDER BY 1, 2




DECLARE @DateFFF DATETIME, @DateFFF2 DATETIME, @DateTo2 DATETIME

SELECT @DateFFF = MIN(DateOpen) FROM Doc_Doc (NOLOCK) WHERE Deleted = 0
SELECT @DateFFF2 = MIN(StartDate) FROM AB_Abon (NOLOCK) WHERE id_Abon in (SELECT id_Abon FROM #T_AB (NOLOCK))

IF ISNULL(@DateFFF, GETDATE()) > ISNULL(@DateFFF2, GETDATE())
  SET @DateFFF = @DateFFF2

IF @DateTo IS NULL
  SELECT @DateTo = GETDATE()

IF @OrdStr = '1014' SELECT @DateTo = GETDATE() + 30
IF @OrdStr = '1313' SELECT @DateTo = GETDATE() + 30
IF @OrdStr = 'DDD' SELECT @DateTo = GETDATE() + 500
--BEGIN 

  SELECT @DateTo2 = MAX(CAST(CAST(P_Year as VARCHAR) + '.' + CAST(P_Month as VARCHAR) + '.1' as DateTime)) 
  from AB_PM P (NOLOCK) 
  JOIN #T_AB A (NOLOCK) ON A.id_Abon = P.id_Abon
  LEFT JOIN AB_PM_Period PPP (NOLOCK) ON PPP.id_PM = P.id_PM
  where P.deleted=0 AND P.TTType = 0 
  
  IF ISNULL(@DateTo, GETDATE()) < ISNULL(@DateTo2, GETDATE())
    SET @DateTo = @DateTo2
--END
--select @DateTo return




--select * from #T_AB return

UPDATE #T_AB SET MaxPayDate = (
SELECT MAX(CAST(CAST(P_Year as VARCHAR) + '.' + CAST(P_Month as VARCHAR) + '.1' as DateTime)) AS DDD
from AB_PM P (NOLOCK) 
LEFT JOIN AB_PM_Period PPP (NOLOCK) ON PPP.id_PM = P.id_PM
where deleted=0 AND P.id_Abon = #T_AB.id_Abon  AND TTType = 0)

insert into _LOG(MMM) VALUES('MaxPayDate')  
-- SELECT @DateFFF, @DateTo
DECLARE @D DATETIME

SET @D = @DateFFF

CREATE TABLE #PPP(P_Year INT, P_Month INT, DDD DATETIME)
WHILE @D <= @DateTo
BEGIN
  INSERT INTO #PPP(P_Year, P_Month, DDD)
  VALUES( YEAR(@D), MONTH(@D), CAST(CAST(YEAR(@D) as VARCHAR) + '.' + CAST(MONTH(@D) as VARCHAR) + '.1' as DateTime))


  SET @D = DATEADD(Month, 1, @D)
END

insert into _LOG(MMM) SELECT '��-��v ' + CAST(COUNT(*)  AS VARCHAR) FROM #PPP (NOLOCK)

--select * from #T_AB (NOLOCK)
-- select * from #PPP (NOLOCK) return

--return

  INSERT INTO #T_PER(id_City, id_Abon, id_EQ, id_HomeType, P_Year, P_Month, DDD, DateOpen, StartDate, MaxPayDate)
  SELECT id_City, id_Abon, id_EQ, id_HomeType, 
    P_Year, P_Month,  DDD, 
    DateOpen, StartDate, MaxPayDate
  FROM #T_AB (NOLOCK), #PPP(NOLOCK)
--select * from #T_PER
--return

insert into _LOG(MMM) SELECT '��v-�v ��v�� ' + CAST(COUNT(*)  AS VARCHAR) FROM #T_PER (NOLOCK)

--select @DateFFF, @DateTo
--select * from #T_PER return

SELECT P.id_Abon, CAST(CAST(P_Year as VARCHAR) + '.' + CAST(P_Month as VARCHAR) + '.1' as DateTime) AS DDD_DEL
INTO #Need_Del
from AB_PM P (NOLOCK) 
JOIN #T_AB AB (NOLOCK) ON AB.id_Abon = P.id_Abon
LEFT JOIN AB_PM_Period PPP (NOLOCK) ON PPP.id_PM = P.id_PM
where P.deleted=0 AND TTType = 1
AND 
CAST(CAST(P_Year as VARCHAR) + '.' + CAST(P_Month as VARCHAR) + '.1' as DateTime) <= @DateTo



DELETE FROM #T_PER 
WHERE EXISTS(SELECT * FROM #Need_Del XXX (NOLOCK) WHERE XXX.id_Abon = #T_PER.id_Abon AND XXX.DDD_DEL = #T_PER.DDD)



DELETE FROM #T_PER WHERE DateOpen IS NOT NULL AND CAST(DateOpen AS INT) > CAST(DDD AS INT) --1013 OR GETDATE() < DDD

DELETE FROM #T_PER WHERE StartDate IS NOT NULL AND CAST(StartDate AS INT) > CAST(DDD AS INT) --1013 OR GETDATE() < DDD

insert into _LOG(MMM) SELECT '��v-�v ���--��v ' + CAST(COUNT(*)  AS VARCHAR) FROM #T_PER (NOLOCK)
--select * from #T_PER (NOLOCK) return
--select * from #T_PER 
  
UPDATE #T_PER SET 
  id_EQ = ISNULL((SELECT MAX(E.id_EQ) FROM #EQH E (NOLOCK) WHERE E.id_Abon = #T_PER.id_Abon
                 AND E.DTo > #T_PER.DDD AND (E.DFrom <= #T_PER.DDD OR E.DFrom  IS NULL))
, id_EQ)
WHERE EXISTS(SELECT * FROM #EQH E (NOLOCK) WHERE E.id_Abon = #T_PER.id_Abon)

--select * from #T_PER return


insert into _LOG(MMM) SELECT '-����-� ���������-� ' + CAST(COUNT(*)  AS VARCHAR) FROM #EQH (NOLOCK)

UPDATE #T_PER
  SET NeedPay = (SELECT MAX(Price) FROM Dic_EQPrice EQP (NOLOCK) 
                 WHERE DateFrom = (
                   SELECT MAX(DateFrom) 
                   FROM Dic_EQPrice PPP (NOLOCK) 
                   WHERE (PPP.id_HomeType = #T_PER.id_HomeType OR PPP.id_HomeType IS NULL)
                     AND (PPP.id_City = #T_PER.id_City OR PPP.id_City IS NULL)
                     AND (PPP.id_EQ = #T_PER.id_EQ OR PPP.id_EQ IS NULL)
                         AND DateFrom <= #T_PER.DDD
                         AND (@PD IS NULL OR @PD >= DateFrom))
                 AND (EQP.id_HomeType = #T_PER.id_HomeType OR EQP.id_HomeType IS NULL)
                 AND (EQP.id_City = #T_PER.id_City OR EQP.id_City IS NULL)
                 AND (EQP.id_EQ = #T_PER.id_EQ OR EQP.id_EQ IS NULL)
               ),
NeedPay2 = (SELECT MAX(Price) FROM Dic_EQPrice EQP (NOLOCK) 
                 WHERE DateFrom = (
                   SELECT MAX(DateFrom) 
                   FROM Dic_EQPrice PPP (NOLOCK) 
                   WHERE (PPP.id_HomeType = #T_PER.id_HomeType )
                     AND (PPP.id_City = #T_PER.id_City OR PPP.id_City IS NULL)
                     AND (PPP.id_EQ = #T_PER.id_EQ OR PPP.id_EQ IS NULL)
                         AND DateFrom <= #T_PER.DDD
                         AND (@PD IS NULL OR @PD >= DateFrom))
                 AND (EQP.id_HomeType = #T_PER.id_HomeType )
                 AND (EQP.id_City = #T_PER.id_City OR EQP.id_City IS NULL)
                 AND (EQP.id_EQ = #T_PER.id_EQ OR EQP.id_EQ IS NULL)
               )

UPDATE #T_PER
  SET NeedPay = NeedPay2 WHERE NeedPay2 IS NOT NULL
--WHERE (@PD IS NULL OR @PD > DDD) 
--select * from #T_PER return
DECLARE @XXX MONEY

--SELECT TOP 1 @XXX =  NeedPay FROM #T_PER (NOLOCK) WHERE NeedPay > 0 ORDER BY id_XXX DESC
--UPDATE #T_PER
  --SET NeedPay = @XXX
--WHERE NeedPay IS NULL AND @PD IS NOT NULL

--SELECT * FROM #T_PER RETURN
 insert into _LOG(MMM) VALUES('����-���v ���-�v')  

IF isnull(@OrdStr, '') = '1313' 
BEGIN
--SELECT * FROM #T_PER (NOLOCK)
insert into _LOG(MMM) VALUES('����v� �v����-')  

  DELETE FROM _XXX_T_PER WHERE id_Abon in (SELECT id_Abon FROM #T_AB (NOLOCK))

  INSERT INTO _XXX_T_PER(id_EQ2, id_Abon, P_Year, P_Month, NeedPay, Total, Payed, Delta)
  SELECT id_EQ, id_Abon, P_Year, P_Month, NeedPay, Total, Payed, Delta
  FROM #T_PER (NOLOCK)

insert into _LOG(MMM) VALUES('����v� �v����- 2')  

    UPDATE AB_PM_PERIOD SET NeedPay = ISNULL((SELECT SUM(ISNULL(X.NeedPay, 0)) 
                FROM AB_PM P (NOLOCK) 
                JOIN _XXX_T_PER X (NOLOCK) ON X.id_Abon = P.id_Abon 
                      AND X.P_Year = AB_PM_PERIOD.P_Year
                      AND X.P_Month = AB_PM_PERIOD.P_Month
                WHERE P.ID_PM = AB_PM_PERIOD.ID_PM), 0)

  UPDATE AB_PM SET 
  Summ = ISNULL((SELECT SUM(NeedPay) FROM AB_PM_PERIOD (NOLOCK) WHERE AB_PM_PERIOD.ID_PM = AB_PM.ID_PM), 0)


  IF 1=2
  BEGIN
    UPDATE AB_PM_PERIOD SET NeedPay = ISNULL((SELECT SUM(ISNULL(X.NeedPay, 0)) 
                FROM AB_PM P (NOLOCK) 
                JOIN #T_PER X (NOLOCK) ON X.id_Abon = P.id_Abon 
                      AND X.P_Year = AB_PM_PERIOD.P_Year
                      AND X.P_Month = AB_PM_PERIOD.P_Month
                WHERE P.ID_PM = AB_PM_PERIOD.ID_PM), 0)

    UPDATE AB_PM SET 
      Summ = ISNULL((SELECT SUM(NeedPay) FROM AB_PM_PERIOD (NOLOCK) WHERE AB_PM_PERIOD.ID_PM = AB_PM.ID_PM), 0)
  END
insert into _LOG(MMM) VALUES('�v����- ����v��v')  
  RETURN
END
 -- select * from Dic_EQPrice
 -- select * from #T_PER RETURN
IF 1=1
BEGIN
  SELECT NeedPay, AB.id_Abon, P_Year, P_Month
  INTO #TARIFF
  FROM AB_PM P (NOLOCK)
  JOIN AB_PM_Period PER (NOLOCK) ON PER.id_PM = P.id_PM
  JOIN #T_AB AB (NOLOCK) ON AB.id_Abon = P.id_Abon
  where (isnull(@OrdStr, '') = '1014' OR isnull(@OrdStr, '') = 'DDD') 
    and P.id_PM <> isnull(@id_PM, -1) and p.deleted = 0 AND TTType = 0

  UPDATE #T_PER
  SET NeedPay = ISNULL((SELECT MAX(NeedPay) FROM #TARIFF P (NOLOCK) 
      WHERE  #T_PER.id_Abon = P.id_Abon
        AND #T_PER.P_Year = P.P_Year
        AND #T_PER.P_Month = P.P_Month), NeedPay)
  WHERE (isnull(@OrdStr, '') = '1014' OR isnull(@OrdStr, '') = 'DDD')
--select * from #T_PER
--select * from #TARIFF return

--select * from #T_PER where NeedPay > 1 return
--select count(*) FROM 

UPDATE #T_PER SET NeedPay = (SELECT MAX(CurTariff) FROM #T_AB A (NOLOCK) WHERE A.id_Abon = #T_PER.id_Abon)
WHERE NeedPay IS NULL

insert into _LOG(MMM) VALUES('���� 1')  


--select * from #T_PER where NeedPay > 1 return

--UPDATE #T_PER SET NeedPay = 22.0
--WHERE NeedPay IS NULL
END



--select * from #T_PER return


DELETE FROM #T_PER WHERE NeedPay IS NULL




CREATE TABLE #T_PM (
	[id_PM] [int] ,
	[id_Abon] [int] ,
	Summ money
)
--select * from #T_PER return
INSERT INTO #T_PM(id_PM, id_Abon, Summ)
SELECT P.id_PM, P.id_Abon, MIN(Summ)
from AB_PM P (NOLOCK) 
JOIN #T_AB AB (NOLOCK) ON AB.id_Abon = P.id_Abon
LEFT JOIN AB_PM_Period PPP (NOLOCK) ON PPP.id_PM = P.id_PM
JOIN AB_Abon A (NOLOCK) ON A.id_Abon = P.id_Abon
JOIN Doc_Doc D (NOLOCK) ON D.id_Doc = A.id_Doc
where P.deleted=0 AND TTType = 0
AND 
(CAST(CAST(P_Year as VARCHAR) + '.' + CAST(P_Month as VARCHAR) + '.1' as DateTime) <= @DateTo  OR
(P_Year IS NULL AND P_Month IS NULL))
AND (@id_City = D.id_City OR @id_City IS NULL)
 and P.id_PM <> isnull(@id_PM, -1)GROUP BY P.id_PM, P.id_Abon



insert into _LOG(MMM) VALUES('���� 2')  

--SELECT * FROM #T_PM
IF @Off = 1 
BEGIN
  SELECT id_Abon, NeedPay = SUM(ISNULL(P.NeedPay, 0))
  INTO #NeedPay
  FROM #T_PER P (NOLOCK)
  GROUP BY P.id_Abon

  SELECT P.id_Abon, WasPay = SUM(ISNULL(P.Summ, 0))
  INTO #WasPay
  FROM #T_PM P (NOLOCK) 
  GROUP BY P.id_Abon

--select * FROM #NeedPay
--select * FROM #WasPay

  SELECT P.id_Abon, DLT = NeedPay - ISNULL(WasPay, 0)
  INTO #ClosedAb
  FROM #NeedPay P (NOLOCK)
  LEFT JOIN #WasPay W (NOLOCK) ON W.id_Abon = P.id_Abon --AND NeedPay = WasPay

--SELECT * FROM #ClosedAb RETURN

  UPDATE #T_PER 
    SET Closed = 1
  WHERE id_Abon IN (SELECT id_Abon FROM #ClosedAb (NOLOCK) WHERE DLT = 0)
END


insert into _LOG(MMM) VALUES('���� 3')  

--SELECT * FROM #T_PM_WP PPP (NOLOCK) WHERE PPP.id_PM IN (SELECT id_PM FROM #T_PM (NOLOCK) WHERE ISNULL(Summ, 0) = ISNULL(NeedPay,0 ))
--SELECT * 
--FROM #T_PM (NOLOCK)
--WHERE ISNULL(Summ, 0) <> ISNULL(NeedPay,0 )

--DELETE FROM #T_PER WHERE Closed = 1



UPDATE #T_PER SET Total =
  isnull((SELECT SUM(NeedPay) FROM #T_PER T (NOLOCK) WHERE T.id_Abon = #T_PER.id_Abon AND T.DDD <= #T_PER.DDD), 0)
WHERE Closed = 0


UPDATE #T_PER SET Payed = isnull((SELECT SUM(Summ) FROM #T_PM T (NOLOCK) WHERE T.id_Abon = #T_PER.id_Abon), 0)
WHERE Closed = 0

DELETE FROM #T_PER WHERE ISNULL(Payed, 0) = 0 AND GETDATE() < DDD

UPDATE #T_PER SET Payed = isnull((SELECT SUM(Summ) FROM #T_PM T (NOLOCK) WHERE T.id_Abon = #T_PER.id_Abon), 0)
WHERE Closed = 0

UPDATE #T_PER SET Delta = 0 WHERE Payed > Total
UPDATE #T_PER SET Delta = 
  CASE 
    WHEN Total - Payed  >  NeedPay THEN NeedPay
    ELSE Total - Payed
  END
WHERE Payed <= Total AND Closed = 0

insert into _LOG(MMM) VALUES('���� 4')  

--select * from #T_PER return



--select * from #T_PER return

UPDATE #T_PER SET NeedPay = ISNULL((SELECT MAX(CurTariff) FROM #T_AB A (NOLOCK) WHERE A.id_Abon = #T_PER.id_Abon AND A.id_EQ = #T_PER.id_EQ), NeedPay),
Delta = Delta + ISNULL((SELECT MAX(CurTariff) FROM #T_AB A (NOLOCK) WHERE A.id_Abon = #T_PER.id_Abon AND A.id_EQ = #T_PER.id_EQ), NeedPay) - NeedPay
WHERE Delta > 0 AND Closed = 0
AND (@PD IS NULL OR @PD > DDD)  

--select * from #T_PER return


insert into _LOG(MMM) VALUES('���� 5')  


IF isnull(@OrdStr, '') = '1014' 
BEGIN
insert into _LOG(MMM) VALUES('�������-� ����v�')  

  DELETE FROM _XXX_T_PER WHERE id_Abon in (SELECT id_Abon FROM #T_AB (NOLOCK))

  INSERT INTO _XXX_T_PER(id_EQ2, id_Abon, P_Year, P_Month, NeedPay, Total, Payed, Delta)
  SELECT id_EQ, id_Abon, P_Year, P_Month, NeedPay, Total, Payed, Delta
  FROM #T_PER (NOLOCK)

  UPDATE AB_Abon 
  SET LPD = (SELECT MAX(DDD) FROM #T_PER P (NOLOCK) WHERE P.id_Abon = AB_Abon.id_Abon AND Delta <= 0) 
  WHERE id_Abon in (SELECT id_Abon FROM #T_AB (NOLOCK))


  UPDATE AB_Abon 
  SET DeptSum = (SELECT MAX(Delta) FROM #T_PER P (NOLOCK) WHERE P.id_Abon = AB_Abon.id_Abon AND 
  DDD = DATEADD(m, 1, LPD)) 
  WHERE id_Abon in (SELECT id_Abon FROM #T_AB (NOLOCK))


  
  SELECT id_Abon, MIN(CAST(CAST(ISNULL(P_Year, 2006) as VARCHAR) + '.' + CAST(P_Month as VARCHAR) + '.1' as DateTime)) AS DDD
  INTO #FPD   
  FROM AB_PM_Period PP (NOLOCK)
  JOIN AB_PM P (NOLOCK) ON P.id_PM = PP.id_PM
  WHERE id_Abon in (SELECT id_Abon FROM #T_AB (NOLOCK))
  GROUP BY id_Abon

  UPDATE AB_Abon SET FPD = (SELECT MIN(DDD) FROM #FPD P (NOLOCK) WHERE P.id_Abon = AB_Abon.id_Abon)
  WHERE id_Abon in (SELECT id_Abon FROM #T_AB (NOLOCK))


--  DELETE FROM AB_Dept_Period 
 -- WHERE EXISTS(SELECT * FROM #T_PER T (NOLOCK) WHERE T.id_Abon = AB_Dept_Period.id_Abon
 --   AND Delta <= 0 AND ADate = DDD)

  RETURN

END
--SELECT * FROM #ClosedAb (NOLOCK) WHERE DLT < 0

IF isnull(@OrdStr, '') = '' OR @OrdStr = 'DDD'
BEGIN

--select * from #T_PER return
--select @Sign
SELECT ID_XXX, A.id_Doc, P.id_Abon, 
DDD,
A.FIO, 
A.Cnt, AbonComment, Ct.Name AS CityName, Street, Home, Corp, Podd, FlatNum, 
dbo.FormatInt(DocNum, 4) + dbo.FormatInt(FlatNum, 3) + ISNULL(LetterIndex, '') AS DN, EQ.Name as EQName, 
HT.Name as HTName, 
NeedPay, Total, Payed, Delta, Closed , D.DateOpen
FROM #T_PER P (NOLOCK) 
JOIN AB_Abon A (NOLOCK) ON A.id_Abon = P.id_Abon
JOIN Doc_Doc D (NOLOCK) On D.id_Doc = A.id_Doc
JOIN Dic_City Ct (NOLOCK) On Ct.id_City = D.id_City
LEFT JOIN Dic_EQ EQ (NOLOCK) On EQ.id_EQ = P.id_EQ
LEFT JOIN Dic_HomeType HT (NOLOCK) On HT.id_HomeType = D.id_HomeType
WHERE (DDD >= @DateFrom OR @DateFrom IS NULL)
--AND  DDD < GETDATE() 
AND  ((@Sign = 0 AND Delta = 0) OR (@Sign * ISNULL(Delta, 0) > 0 ) OR @Sign IS NULL)
ORDER BY A.FIO, P.id_Abon, DDD DESC
return
END







SET NOCOUNT OFF

DECLARE @SQLString NVARCHAR(4000)

SET @SQLString = N'SELECT * FROM  #REZZZ (NOLOCK) ORDER BY ' + @OrdStr 

IF @SQLString IS NULL
  EXEC sp_executesql N'SELECT * FROM  #REZZZ (NOLOCK)'
ELSE 
  EXEC sp_executesql @SQLString

*/

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

