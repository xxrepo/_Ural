if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AB_AbonGetCountByDocNum]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AB_AbonGetCountByDocNum]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AB_DocGetCountByDocNum]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AB_DocGetCountByDocNum]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[PD_PDAdd]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[PD_PDAdd]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[PD_PDDel]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[PD_PDDel]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[PD_PDEdit]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[PD_PDEdit]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[PD_PDGetDocNum]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[PD_PDGetDocNum]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[PD_PDGetList]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[PD_PDGetList]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[PD_PDGetProp]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[PD_PDGetProp]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE AB_AbonGetCountByDocNum
  @DocNum VARCHAR(255) = null,
  @id_Abon INT = NULL
AS

SET NOCOUNT ON


SELECT count(distinct id_Abon) as CNT -- dbo.FormatInt(DocNum, 4) + dbo.FormatInt(FlatNum, 3) + ISNULL(LetterIndex, '')  -- count(*) as CNT
from AB_Abon A (NOLOCK) 
JOIN Doc_Doc D (NOLOCK) On D.id_Doc = A.id_Doc
where A.deleted=0  
AND 
(
dbo.FormatInt(DocNum, 4) + dbo.FormatInt(FlatNum, 3) + ISNULL(LetterIndex, '') like '0' + @DocNum + '%' 
OR dbo.FormatInt(DocNum, 4) + dbo.FormatInt(FlatNum, 3) + ISNULL(LetterIndex, '') like '' + @DocNum + '%' 
)
AND (id_Abon <> @id_Abon OR @id_Abon IS NULL)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE AB_DocGetCountByDocNum
  @DocNum VARCHAR(255) = null,
  @id_Doc INT = NULL
AS

SET NOCOUNT ON


SELECT count(distinct id_DOc) as CNT -- dbo.FormatInt(DocNum, 4) + dbo.FormatInt(FlatNum, 3) + ISNULL(LetterIndex, '')  -- count(*) as CNT
FROM Doc_Doc D  
where D.deleted=0 AND DocNum = @DocNum
AND (id_Doc <> @id_Doc OR @id_Doc IS NULL)

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE PD_PDAdd
  @id_Abon INT,
  @DocNum integer = NULL,
  @PayBase VARCHAR(255) = NULL,
  @Summ money,
  @id_User INT
AS
INSERT INTO PD_PD(
id_Abon,
DocNum,
PayBase,
Summ,
id_User
)
VALUES(
@id_Abon,
@DocNum,
@PayBase,
@Summ,
@id_User
)
RETURN @@IDENTITY
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE PD_PDDel
  @id_PD INT
AS
UPDATE PD_PD SET Disabled = 1
WHERE id_PD = @id_PD

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE PD_PDEdit
  @id_PD INT,
  @id_Abon INT,
  @DocNum integer = NULL,
  @PayBase VARCHAR(255) = NULL,
  @Summ money,
  @id_User INT
AS
UPDATE PD_PD SET
id_Abon = @id_Abon,
DocNum = @DocNum,
PayBase = @PayBase,
Summ = @Summ,
id_User = @id_User
WHERE id_PD = @id_PD
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE PD_PDGetDocNum
AS

DECLARE @DocNum INT
DECLARE @DocNum2 INT

SELECT @DocNum = max(DocNum) + 1 
FROM PD_PD P (NOLOCK) 
WHERE P.Disabled=0

SELECT @DocNum2 = max(DocNum) + 1 
FROM PD_NUM P (NOLOCK) 

IF @DocNum2 > @DocNum SET @DocNum = @DocNum2

INSERT INTO PD_NUM(DocNum) VALUES (@DocNum)

SELECT @DocNum
RETURN @DocNum
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE PD_PDGetList
  @id_Abon INT,
  @D1 DATETIME ,
  @D2 DATETIME 
AS
SELECT P.*, A.FIO, dbo.FormatInt(DocNum, 4) + dbo.FormatInt(FlatNum, 3) + ISNULL(LetterIndex, '') AS DN 
FROM PD_PD P (NOLOCK) 
JOIN AB_Abon A (NOLOCK)  ON A.id_Abon=P.id_Abon
WHERE (P.id_Abon = @id_Abon OR @id_Abon = -1)
AND P.Datecreate >= @D1
AND P.Datecreate <= @D2
AND P.Disabled=0
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE PD_PDGetProp
  @id_PD INT
AS
SELECT P.*  
FROM PD_PD P (NOLOCK)
WHERE id_PD= @id_PD
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

