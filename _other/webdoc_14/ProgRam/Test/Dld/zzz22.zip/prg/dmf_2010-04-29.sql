use DMF
GO

alter table Dic_EQ add OrderID int
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Dic_EQSetOrderID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Dic_EQSetOrderID]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO


CREATE PROCEDURE Dic_EQSetOrderID
  @id_EQ INT,
  @OrderID INT
AS

UPDATE Dic_EQ
SET OrderID = @OrderID
WHERE id_EQ = @id_EQ

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AB_Period]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[AB_Period]
GO

CREATE TABLE [dbo].[AB_Period] (
	[id_P] [int] IDENTITY (1, 1) NOT NULL ,
	[id_Abon] [int] NOT NULL ,
	[P_Year] [int] NOT NULL ,
	[P_Month] [int] NOT NULL ,
	[P_DDD] [datetime] NULL ,
	[id_EQ] [int] NULL ,
	[EQName] [varchar] (255) COLLATE Cyrillic_General_CI_AS NULL ,
	[Tariff] [money] NULL ,
	[Tariff_real] [money] NULL ,
	[FullPayDate] [datetime] NULL ,
	[Total] [money] NULL ,
	[cmnt] [varchar] (255) COLLATE Cyrillic_General_CI_AS NULL 
) ON [PRIMARY]
GO




if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AB_AbonProp]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AB_AbonProp]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AB_GetCurPrice]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AB_GetCurPrice]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AB_PMProp]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AB_PMProp]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AB_PM_UNCalc_GetList]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AB_PM_UNCalc_GetList]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AB_PM_UNCalc_v2]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AB_PM_UNCalc_v2]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Ag_GetCurPrice]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Ag_GetCurPrice]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Dic_EQGetList]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Dic_EQGetList]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Dic_EQPriceGetList]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Dic_EQPriceGetList]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO







CREATE PROCEDURE AB_AbonProp
  @id_Abon INT
 AS

SET NOCOUNT ON
DECLARE @NeedPay MONEY
DECLARE @id_HomeType INT, @id_City INT, @id_EQ INT


SELECT @id_HomeType = id_HomeType, @id_City = id_City, @id_EQ = id_EQ
FROM AB_Abon A (NOLOCK) 
JOIN Doc_Doc D (NOLOCK) ON D.id_Doc = A.id_Doc
WHERE A.id_Abon = @id_Abon

--select @id_HomeType, @id_City, @id_EQ

EXEC AB_GetCurPrice @id_Abon, @NeedPay OUTPUT

-- @NeedPay = isnull( @NeedPay2, @NeedPay)



SELECT StartDate = ISNULL(StartDate, DateOpen), A.*, DD.id_City, CT.Name AS CityName, HT.NAme AS HTName, Street, Home, Corp, 
dbo.FormatInt(DocNum, 4) + dbo.FormatInt(FlatNum, 3)  + ISNULL(LetterIndex, '') AS DN,
@NeedPay AS DefPrice, EQ.Name as EQName
from AB_Abon A (NOLOCK)
JOIN Doc_Doc DD (NOLOCK) ON DD.id_Doc = A.id_Doc
JOIN Dic_City CT (NOLOCK) ON CT.id_City = DD.id_City
LEFT JOIN Dic_HomeType HT (NOLOCK) ON HT.id_HomeType = DD.id_HomeType
LEFT JOIN Dic_EQ EQ (NOLOCK) On EQ.id_EQ = A.id_EQ

where A.deleted=0 AND A.id_Abon = @id_Abon

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE AB_GetCurPrice
  @id_Abon INT = NULL, @CurPrice MONEY OUTPUT, @RetRez INT = 0
AS

  DECLARE @id_EQ INT, @id_Doc INT,   @id_City INT,  @id_HomeType INT 

  select @id_EQ=id_EQ, @id_Doc = A.id_Doc , @id_City = id_City, @id_HomeType = id_HomeType
  FROM AB_ABon A (NOLOCK) 
  JOIN Doc_Doc DD (NOLOCK) ON DD.id_Doc = A.id_Doc 
  WHERE id_Abon= @id_Abon

  SET @CurPrice = (SELECT TOP 1 Price FROM Dic_EQPrice EP WHERE EP.id_EQ=@id_EQ AND ISNULL(EP.id_City, @id_City) = @id_City AND ISNULL(EP.id_HomeType, @id_HomeType) = @id_HomeType AND Datediff(dd, DateFrom,getdate()) >= 0 ORDER BY id_City DESC, DateFrom DESC)
  if @RetRez = 1 SELECT @CurPrice AS CurPrice

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE AB_PMProp
  @id_PM INT,
  @id_Abon INT
 AS

SET NOCOUNT ON

DECLARE @NeedPay MONEY, @NeedPay2 MONEY
DECLARE @id_HomeType INT, @id_City INT, @id_EQ INT


SELECT @id_HomeType = id_HomeType, @id_City = id_City, @id_EQ = id_EQ
FROM AB_Abon A (NOLOCK) 
JOIN Doc_Doc D (NOLOCK) ON D.id_Doc = A.id_Doc
WHERE A.id_Abon = @id_Abon

EXEC AB_GetCurPrice @id_Abon, @NeedPay OUTPUT


SELECT P.*, A.FIO, CT.Name AS CityName, HT.NAme AS HTName, Street, Home, Corp, FlatNum, dbo.FormatInt(DocNum, 4) + dbo.FormatInt(FlatNum, 3) AS DN,
@NeedPay AS DefPrice
from AB_PM P (NOLOCK) 
JOIN AB_Abon A (NOLOCK) ON P.id_Abon = A.id_Abon
JOIN Doc_Doc DD (NOLOCK) ON DD.id_Doc = A.id_Doc
JOIN Dic_City CT (NOLOCK) ON CT.id_City = DD.id_City
left JOIN Dic_HomeType HT (NOLOCK) ON HT.id_HomeType = DD.id_HomeType

where P.deleted=0 AND P.id_PM = @id_PM

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



CREATE PROCEDURE AB_PM_UNCalc_GetList
  @id_Abon INT = NULL
 AS

DECLARE @DateStart DATETIME 

SELECT @DateStart=min(COALESCE(StartDate, DateOpen)) 
FROM Doc_Doc D (NOLOCK)
JOIN AB_Abon A (NOLOCK) ON A.id_Doc = D.id_DOc
WHERE @id_Abon = id_Abon

select P_Year, P_Month, P_DDD, EQName, Tariff, Tariff_real, FullPayDate, cmnt, NULL AS id_PM, 1 as XXX
from AB_Period (NOLOCK) where id_Abon = @id_Abon 

UNION ALL

SELECT Null, Null, COALESCE(PayDate, @DateStart, DateCreate) as P_DD, Null, -Summ, -Summ, COALESCE(PayDate, @DateStart, DateCreate), PMComment, id_PM, 2 as XXX 
FROM AB_PM (NOLOCK) where id_Abon = @id_Abon and deleted=0
ORDER BY P_DDD DESC, XXX
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE AB_PM_UNCalc_v2 
  @id_Abon INT = NULL
 AS


SET NOCOUNT ON

insert into _LOG(MMM) VALUES('������') 

CREATE TABLE #Period (
	[id_P] [int] IDENTITY (1, 1) ,
	[P_Year] [int] NOT NULL ,
	[P_Month] [int] NOT NULL ,
	[P_DDD] [DATETIME] NULL ,
        id_EQ [int],
        EQName VARCHAR(255), 
	[Tariff] [money] NULL ,
        [Tariff_real] [money] NULL ,

	[FullPayDate] [DATETIME] NULL ,
	[Total] [money] NULL,
        cmnt varchar(255)
) 


DECLARE @I INT, @N INT, @id_EQ INT, @id_City INT, @id_HomeType INT, @DateStart DATETIME

INSERT INTO #Period(P_Year, P_Month) EXEC AA_MonthList @id_Abon 
UPDATE #Period SET id_EQ = @id_EQ, P_DDD = CAST(CAST(P_Year as VARCHAR) + '.' + CAST(P_Month as VARCHAR) + '.01' as DateTime)



SELECT @N = MAX(id_P), @DateStart = min(P_DDD) FROM #Period (NOLOCK)

SELECT @id_EQ = id_EQ, @id_City = id_City , @id_HomeType = id_HomeType
FROM Doc_Doc D (NOLOCK)
JOIN AB_Abon A (NOLOCK) ON A.id_Doc = D.id_DOc
WHERE id_Abon = @id_Abon

SELECT * INTO #TMP_EQ_Hst FROM AB_EQ EQ (NOLOCK) WHERE id_Abon = @id_Abon

SELECT *, CAST(Null as DateTime) as DateTo INTO #TMP_EQPrice 
FROM Dic_EQPrice (NOLOCK) 
WHERE (id_EQ = @id_EQ OR id_EQ IN (SELECT id_EQ FROM #TMP_EQ_Hst (NOLOCK))) 
and @id_City = id_City AND (@id_HomeType = id_HomeType OR id_HomeType IS NULL)
ORDER BY DateFrom

select @id_City, @id_HomeType, @id_EQ, * from #TMP_EQ_Hst

UPDATE #TMP_EQPrice SET DateTo = isnull((SELECT MAX(DateFrom) FROM #TMP_EQPrice Z WHERE Z.id_EQ=#TMP_EQPrice.id_EQ AND Z.id_EQPrice<>#TMP_EQPrice.id_EQPrice AND Z.DateFrom>#TMP_EQPrice.DateFrom) - 1, Getdate()+3650)

--select * from #Period
--select @id_EQ, @id_City, @id_HomeType  
--select * from #TMP_EQ_Hst
--select * from #TMP_EQPrice


UPDATE #Period SET id_EQ = COALESCE(
(SELECT MAX(id_EQ) FROM #TMP_EQ_Hst H WHERE DateFromEQ =(SELECT MAX(DateFromEQ) FROM #TMP_EQ_Hst H WHERE DateFromEQ <= P_DDD))
, @id_EQ)

UPDATE #Period SET Tariff = 
(SELECT MAX(Price) FROM #TMP_EQPrice Z WHERE DateFrom =(SELECT MAX(DateFrom) FROM #TMP_EQPrice H WHERE DateFrom <= P_DDD AND #Period.id_EQ=H.id_EQ AND Z.id_EQ=H.id_EQ))

UPDATE #Period SET EQName = (SELECT MAX(Name) FROm DIC_EQ E WHERE E.id_EQ=#Period.id_EQ),
  Total = (select sum(isnull(Tariff, 0)) from #Period Z WHERE Z.id_P <= #Period.id_P)  


SELECT IDENTITY (INT) as ID, 
PDate = COALESCE(PayDate, @DateStart, DateCreate), sum(Summ) as Summ, CAST(Null as DateTime) AS PM_DDD 
INTO #PM
FROM AB_PM (NOLOCK) 
WHERE id_Abon=@id_Abon and deleted=0
GROUP BY COALESCE(PayDate, @DateStart, DateCreate)
ORDER BY COALESCE(PayDate, @DateStart, DateCreate)

UPDATE #PM SET PM_DDD = CAST(CAST(Year(PDate) as VARCHAR) + '.' + CAST(Month(PDate) as VARCHAR) + '.01' as DateTime)

--select *, @DateStart from #PM

DECLARE @Tariff MONEY, @Tariff_OLD MONEY, @Tariff_real MONEY, @SUMM MONEY, @P_DDD DATETIME, @ID INT, @MAX_ID INT, @PDate DATETIME
SELECT @i = 1, @ID = 1
SELECT @MAX_ID = MAX(ID) FROM #PM
--select @ID, @MAX_ID, @i, @N
WHILE @ID <= @MAX_ID
BEGIN

  WHILE @i <= @N
  BEGIN
    SELECT @SUMM = sum(Summ), @PDate = max(CASE WHEN Summ > 0 THEN PDate ELSE NULL END) FROM #PM WHERE (ID <= @ID AND Summ > 0) OR (Summ < 0)

    SELECT @id_EQ=id_EQ, @Tariff = ISNULL(Tariff_real, Tariff), @P_DDD = P_DDD FROM #Period WHERE id_P = @i
    SELECT @Tariff_real = MAX(Price) FROM #TMP_EQPrice WHERE id_EQ = @id_EQ AND DateFrom <= @PDate AND DateTo >= @PDate
   -- select @Tariff_real, @SUMM
    IF @Tariff_real <= @SUMM 
    BEGIN
      UPDATE #Period SET FullPayDate = @PDate, Tariff_real = @Tariff_real WHERE id_P = @i
      INSERT INTO #PM(Summ, PDate) VALUES(-1 * @Tariff, @P_DDD)
     -- UPDATE #Period SET cmnt = 'sss'  WHERE id_P = @i 
      SET @i = @i + 1
    END
    ELSE
    BEGIN
      BREAK
    END
  END
  SET @ID = @ID + 1
END



--SELECT * FROM #PM
DELETE FROM #Period WHERE P_DDD > Getdate() AND FullPayDate IS NULL
UPDATE #Period SET Tariff_real = (SELECT MAX(Price) FROM #TMP_EQPrice Z WHERE #Period.id_EQ=Z.id_EQ AND DateFrom <= Getdate() AND DateTo >= Getdate())
WHERE FullPayDate IS NULL


DELETE FROM AB_Period WHERE id_Abon=@id_Abon

INSERT INTO AB_Period(id_Abon, P_Year, P_Month, P_DDD, id_EQ, EQName, Tariff, Tariff_real, FullPayDate, Total, cmnt)
SELECT @id_Abon, P_Year, P_Month, P_DDD, id_EQ, EQName, Tariff, Tariff_real, FullPayDate, Total, cmnt FROM #Period (NOLOCK)

SELECT * FROM AB_Period (NOLOCK) WHERE id_Abon=@id_Abon ORDER BY P_DDD DESC
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE Ag_GetCurPrice
  @id_Abon INT = NULL, @CurPrice MONEY OUTPUT
AS

  DECLARE @id_EQ INT, @id_Doc INT,   @id_City INT,  @id_HomeType INT 

  select @id_EQ=id_EQ, @id_Doc = A.id_Doc , @id_City = id_City, @id_HomeType = id_HomeType
  FROM AB_ABon A (NOLOCK) 
  JOIN Doc_Doc DD (NOLOCK) ON DD.id_Doc = A.id_Doc 
  WHERE id_Abon= @id_Abon

  SET @CurPrice = (SELECT TOP 1 Price FROM Dic_EQPrice EP WHERE EP.id_EQ=@id_EQ AND ISNULL(EP.id_City, @id_City) = @id_City AND ISNULL(EP.id_HomeType, @id_HomeType) = @id_HomeType AND Datediff(dd, DateFrom,getdate()) >= 0 ORDER BY id_City DESC, DateFrom DESC)
  SELECT @CurPrice AS CurPrice

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE Dic_EQGetList
  @id_City INT  = Null,
  @id_HomeType INT = Null,  
  @id_Abon INT = NULL
AS

IF @id_City IS NULL AND @id_HomeType IS NULL AND @id_Abon IS NULL
BEGIN
  SELECT id_EQ, Name, Deleted,  OrderID, CAST(NULL AS money) AS CurPrice 
  FROM Dic_EQ (NOLOCK) 
  where deleted = 0 order by OrderID, Name
END
ELSE
BEGIN
  DECLARE @id_EQ INT, @id_Doc INT
  select @id_EQ=id_EQ, @id_Doc = A.id_Doc , @id_City = id_City, @id_HomeType = id_HomeType
  FROM AB_ABon A (NOLOCK) 
  JOIN Doc_Doc DD (NOLOCK) ON DD.id_Doc = A.id_Doc 
  WHERE id_Abon= @id_Abon

  SELECT  OrderID, EQ.id_EQ, EQ.Name, CAST(0 as BIT) as Deleted, CAST(NULL AS money) AS CurPrice , @id_City as id_City, @id_HomeType AS id_HomeType
  INTO #EQ
  FROM Dic_EQ EQ (NOLOCK) 
  JOIN Dic_EQPrice EP (NOLOCK) ON EP.id_EQ=EQ.id_EQ
  where deleted = 0 
  AND 
( 
  (ISNULL(EP.id_City, @id_City) = @id_City AND ISNULL(EP.id_HomeType, @id_HomeType) = @id_HomeType) 
  OR EQ.id_EQ= @id_EQ
)
AND Datediff(dd, DateFrom,getdate()) >= 0
  GROUP BY OrderID, EQ.id_EQ, EQ.Name
  order by OrderID, Name  

--select *, CurPrice = (SELECT TOP 1 Price FROM Dic_EQPrice EP WHERE EP.id_EQ=#EQ.id_EQ AND ISNULL(EP.id_City, @id_City) = @id_City AND ISNULL(EP.id_HomeType, @id_HomeType) = @id_HomeType AND Datediff(dd, DateFrom,getdate()) >= 0 ORDER BY DateFrom DESC) from #EQ

  UPDATE #EQ SET CurPrice = (SELECT TOP 1 Price FROM Dic_EQPrice EP WHERE EP.id_EQ=#EQ.id_EQ AND ISNULL(EP.id_City, @id_City) = @id_City AND ISNULL(EP.id_HomeType, @id_HomeType) = @id_HomeType AND Datediff(dd, DateFrom,getdate()) >= 0 ORDER BY id_City DESC, DateFrom DESC)

  SELECT id_EQ, Name, Deleted, OrderID, CurPrice 
  FROM #EQ (NOLOCK) 
  Order by OrderID, Name
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE procedure Dic_EQPriceGetList
  @id_City INT
AS

SELECT D.*, HT.Name AS HTName, ISNULL( C2.Name + '/', '') + C.Name as CityName, EQNAme = EQ.Name, CAST(NULL AS DATETIME)  AS DateTo
INTO #T
FROM Dic_EQPrice D (NOLOCK)
LEFT JOIN Dic_HomeType HT (NOLOCK) ON HT.id_HomeType = D.id_HomeType
LEFT JOIN Dic_City C (NOLOCK) ON C.id_City = D.id_City
LEFT JOIN Dic_City C2 (NOLOCK) ON C.PID = C2.id_City
JOIN Dic_EQ EQ (NOLOCK) ON EQ.id_EQ = D.id_EQ
WHERE( C.id_City  = @id_City OR @id_City IS NULL OR C2.id_City  = @id_City)
ORDER BY D.DateFrom desc, EQ.Name, HT.Name

UPDATE #T SET DateTo=(SELECT MIN(DDD.DateFrom) FROM Dic_EQPrice DDD (NOLOCK) WHERE #T.DateFrom<DDD.DateFrom AND ISNULL(#T.id_HomeType, -1) = ISNULL(DDD.id_HomeType, -1) 
            AND ISNULL(#T.id_City, -1) = ISNULL(DDD.id_City, -1) AND #T.id_EQ = DDD.id_EQ AND #T.id_EQPrice <> DDD.id_EQPrice)

SELECT * FROM #T (NOLOCK)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

