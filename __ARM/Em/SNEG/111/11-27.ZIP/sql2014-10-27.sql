use ACS1

go

if not exists(select * from dic_Func where UID = 1941) insert into dic_Func(UID, Name)values(1941, '������� ��������')  
if not exists(select * from dic_Func where UID = 1945) insert into dic_Func(UID, Name)values(1945, '���������� ��������')

go



if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[OP_BlockIt]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[OP_BlockIt]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[PL_LastPrice]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[PL_LastPrice]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RPT_NewRepTree_CH]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RPT_NewRepTree_CH]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE OP_BlockIt 
  @id_business INT = 43,
  @VirtDate DATETIME = '04-01-2014 20:15'
AS
DECLARE @DateCreate DATETIME  
SET @id_business = 143 
-- select @VirtDate 
SET @VirtDate = dateadd(day, datediff(day, 0, @VirtDate), 0) + CAST('22:00:00.000' AS DATETIME)

 -- select @VirtDate return
 
SELECT @DateCreate = MAX(VirtDate) FROM DD_Day (NOLOCK) WHERE DateClose IS NULL AND id_business = @id_business
IF @DateCreate > @VirtDate 
begin
  DECLARE @S VARCHAR(255)
  SET @S = '������� �� ' + convert(varchar(20), @VirtDate, 105) + ' ����������. ��������� �������� ���� '  + convert(varchar(20), @DateCreate, 105)
  RAISERROR (@S, 16, 1) 
  RETURN 0
end

/*
if not exists(select * from dic_Func where UID = 1941) insert into dic_Func(UID, Name)values(1941, '������� ��������')  
if not exists(select * from dic_Func where UID = 1945) insert into dic_Func(UID, Name)values(1945, '���������� ��������')
*/


UPDATE OP_Oper2 SET Blocked = 1  WHERE CheckDate IS NOT NULL AND id_business = @id_business
UPDATE OP_Oper2 set DateCreate = @VirtDate WHERE CheckDate IS NULL AND id_business = @id_business AND Deleted=0
--- select * from dic_business
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE PL_LastPrice
  @id_Goods INT
AS

declare @PriceOper FLOAT

select @PriceOper = PriceOper
FROM OP_Oper2 OP (NOLOCK)
JOIN OP_OperWare OW (NOLOCK) ON OW.id_Oper = OP.id_Oper
WHERE DateCreate = (
select max(DateCreate)
FROM OP_Oper2 OP (NOLOCK)
JOIN OP_OperWare OW (NOLOCK) ON OW.id_Oper = OP.id_Oper
WHERE deleted = 0 AND id_Goods = @id_Goods AND id_WareHouse IS NOT NULL AND OperTypeIn = 0 AND id_Manufact_Ext IS NOT NULL
)
AND id_Goods = @id_Goods

IF @PriceOper IS NULL
BEGIN
  select @PriceOper = PriceOper
  FROM ARC_OP_Oper OP (NOLOCK)
  JOIN ARC_OP_OperWare OW (NOLOCK) ON OW.id_Oper = OP.id_Oper
  WHERE DateCreate = (
  select max(DateCreate)
  FROM ARC_OP_Oper OP (NOLOCK)
  JOIN ARC_OP_OperWare OW (NOLOCK) ON OW.id_Oper = OP.id_Oper
  WHERE id_Goods = @id_Goods AND id_WareHouse IS NOT NULL AND OperTypeIn = 0 AND id_Manufact_Ext IS NOT NULL
  )
  AND id_Goods = @id_Goods

END

select @PriceOper as PriceOper



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO




CREATE PROCEDURE RPT_NewRepTree_CH 
  @Id_business INT = 43,
  @Year INT = 2013,

  @Str3 VARCHAR(255) = '�������� ������� � �������, ���',
  @M2 INT = 7

AS
SET @Str3 = ltrim(@Str3)
DECLARE @D1 DATETIME, @D2 DATETIME

  SET @D1 = CAST('01-01-' +CAST(@Year as VARCHAR(10)) as DATETIME)
  SET @D2 = DATEADD(mm, @M2, @D1) + CAST('23:59:59' as DATETIME) - 1
  SET @D1 = DATEADD(mm, @M2 - 2, @D1)  

  DECLARE @id_Rez INT, @i INT
 
--select @D1, @D2 return

DECLARE @WWW TABLE (WorkSum FLOAT, id_OPer INT, ZZZ VARCHAR(255), id_Goods INT)

 SELECT ISNULL(id_OperWare, -1) as id_OperWare, CAST(NULL as FLOAT) as WorkSum, NULL as MMM, id_WareHouse, id_Acc, 
DateCreate, ISNULL(id_Goods, -1) as id_Goods, OC.id_Repr, CR.id_ContrAgent, BO.id_Rez, OC.id_Oper, PriceInv, 
OperRateDeltaCur = ISNULL(CRN_CurChDelta/*CRN_OperRateDelta*/, 0),CRN_OperSum_Inv, OperSummSysCur = CRN_OLD_OperSum_Offer, 
OperTotalDeltaCur = CRN_OperDelta + ISNULL(CRN_OperRateDelta, 0), CRN_CurChDelta, OperVid, OperTypeIn, Koeff, id_Manufact, id_Manufact_Ext, OpComment
  INTO #WWW2
  FROM VW_Oper_WArc_prev_NEW OC (NOLOCK)
  LEFT JOIN BLN_Oper_v2 BO (NOLOCK) ON BO.id_Oper = OC.id_Oper
  LEFT JOIN CA_Repr CR (NOLOCK) ON CR.id_Repr = OC.id_Repr
  WHERE
  HidedOper = 0 AND Deleted = 0 AND
  (@id_business = OC.id_business) AND
  (DateCreate > @D1) AND (DateCreate <= @D2)
  AND OC.CheckDate IS NOT NULL
  AND (BO.id_Rez > @id_Rez OR @id_Rez IS NULL OR BO.id_Rez IS NULL)
 -- AND @M2 = MONTH(DateCreate)

--return
DELETE FROM #WWW2 WHERE id_ContrAgent=4329 AND NOT(OperVid = 1 AND OperTypeIn = 0)

SET @i = @M2 - 1
WHILE @i <= @M2
BEGIN
  SET @D1 = CAST('01-01-' +CAST(@Year as VARCHAR(10)) as DATETIME)
  SET @D1 = DATEADD(mm, @i - 1, @D1)  

  SET @D2 = DATEADD(mm, 1, @D1) + CAST('23:59:59' as DATETIME) - 1

--select @i
  SELECT @id_Rez = MAX(id_Rez)
  FROM BLN_Rez_v2 (NOLOCK) 
  WHERE ddd = 0 AND id_business = @id_business AND (DateCreate < @D1) 
  
  UPDATE #WWW2 SET MMM = @i WHERE (DateCreate <= @D2)  AND (id_Rez > @id_Rez OR @id_Rez IS NULL OR id_Rez IS NULL) AND MMM IS NULL

  SET @i = @i + 1
END

--return
  
 -- DELETE FROM #WWW2 WHERE id_Rez < @id_Rez
 


 --- ������. �������
/*
   INSERT INTO #WWW(ZZZ, id_Oper, id_Goods, WorkSum)
  SELECT '���������� �������, ���', id_Oper, id_Goods, WorkSum = ISNULL(ISNULL(CASE WHEN PriceInv IS NOT NULL THEN CRN_OperSum_Inv ELSE -OperSummSysCur * CASE WHEN Koeff = -1 THEN -1 ELSE 1 END END, 0), 0)
  FROM #WWW2 (NOLOCK) WHERE MMM = @M2 AND ((Koeff = -1) OR (OperVid = 4 AND OperTypeIn = 1 AND Koeff = 0))

  INSERT INTO #WWW(ZZZ, id_Oper, id_Goods, WorkSum)
  SELECT '���������� �������, ���', id_Oper, id_Goods, ISNULL(ISNULL(-OperTotalDeltaCur, 0), 0) 
  FROM #WWW2 (NOLOCK) WHERE MMM = @M2 AND ((OperVid = 1 AND OperTypeIn = 0 AND OperTotalDeltaCur < 0 AND Koeff = 0))

  INSERT INTO #WWW(ZZZ, id_Oper, id_Goods, WorkSum)
  SELECT '���������� �������, ���', id_Oper, id_Goods, ISNULL(-CRN_CurChDelta, 0) 
  FROM #WWW2 (NOLOCK) WHERE MMM = @M2 AND (CRN_CurChDelta < 0 AND NOT(OperVid = 1 AND OperTypeIn = 0))
 */


-- ****************

-- ������ �������� �������
  IF @Str3 = '�������� ������� � �������, ���' --and 1=2
  BEGIN
--select getdate()
    	UPDATE #WWW2 SET WorkSum = - OperSummSysCur
	WHERE MMM = @M2 AND ((id_Manufact_Ext IS NOT NULL AND OperTypeIn = 0) )  AND Koeff = 0
    	UPDATE #WWW2 SET WorkSum = OperSummSysCur
	WHERE MMM = @M2 AND (OperTypeIn = 1 AND id_Manufact IS NOT NULL) AND Koeff = 0


    	UPDATE #WWW2 SET WorkSum = CASE WHEN id_Manufact IS NOT NULL THEN 1 ELSE -1 END * OperSummSysCur
	WHERE MMM = @M2 AND ((id_Manufact_Ext IS NOT NULL AND OperTypeIn = 1 AND id_Manufact_Ext <> 39) OR (OperTypeIn = 0 AND id_Manufact IS NOT NULL AND id_Manufact <> 39))  AND Koeff = 0
  END  

  IF @Str3 = '������� �� �������, ���' --and 1=2
  BEGIN
--select getdate()
    	UPDATE #WWW2 SET WorkSum = - OperSummSysCur
	WHERE MMM = @M2 AND ((id_Manufact_Ext IS NOT NULL AND OperTypeIn = 0) )  AND Koeff = 0
	  AND (OpComment like '%����� �%�-%'  OR OpComment like '%����� �%�-%' )

    	UPDATE #WWW2 SET WorkSum = OperSummSysCur
	WHERE MMM = @M2 AND (OperTypeIn = 1 AND id_Manufact IS NOT NULL) AND Koeff = 0
        AND (OpComment like '%����� �%�-%'  OR OpComment like '%����� �%�-%' )



    	UPDATE #WWW2 SET WorkSum = CASE WHEN id_Manufact IS NOT NULL THEN 1 ELSE -1 END * OperSummSysCur
	WHERE MMM = @M2 AND ((id_Manufact_Ext IS NOT NULL AND OperTypeIn = 1 AND id_Manufact_Ext <> 39) OR (OperTypeIn = 0 AND id_Manufact IS NOT NULL AND id_Manufact <> 39))  AND Koeff = 0
	AND (OpComment like '%����� �%�-%'  OR OpComment like '%����� �%�-%' )
  END  

  IF @Str3 = '��������� c������� �������, ���' --and 1=2
  BEGIN
--select getdate()
    	UPDATE #WWW2 SET WorkSum = - OperSummSysCur
	WHERE MMM = @M2 AND ((id_Manufact_Ext IS NOT NULL AND OperTypeIn = 0) )  AND Koeff = 0
	  AND not (OpComment like '%����� �%�-%' OR OpComment like '%����� �%�-%' )

    	UPDATE #WWW2 SET WorkSum = OperSummSysCur
	WHERE MMM = @M2 AND (OperTypeIn = 1 AND id_Manufact IS NOT NULL) AND Koeff = 0
        AND not (OpComment like '%����� �%�-%'  OR OpComment like '%����� �%�-%' )



    	UPDATE #WWW2 SET WorkSum = CASE WHEN id_Manufact IS NOT NULL THEN 1 ELSE -1 END * OperSummSysCur
	WHERE MMM = @M2 AND ((id_Manufact_Ext IS NOT NULL AND OperTypeIn = 1 AND id_Manufact_Ext <> 39) OR (OperTypeIn = 0 AND id_Manufact IS NOT NULL AND id_Manufact <> 39))  AND Koeff = 0
	AND not (OpComment like '%����� �%�-%'  OR OpComment like '%����� �%�-%' )
  END  


  IF @Str3 = '���������� �������, ���' --and 1=2
  BEGIN
 	UPDATE #WWW2 SET WorkSum = CASE WHEN PriceInv IS NOT NULL THEN CRN_OperSum_Inv ELSE -OperSummSysCur * CASE WHEN Koeff = -1 THEN -1 ELSE 1 END END
        WHERE MMM = @M2 AND ( (Koeff = -1) OR (OperVid = 4 AND OperTypeIn = 1 AND Koeff = 0) )
    	
	UPDATE #WWW2 SET WorkSum = -OperTotalDeltaCur
	WHERE MMM = @M2 AND ((OperVid = 1 AND OperTypeIn = 0 AND OperTotalDeltaCur < 0 AND Koeff = 0))


    	UPDATE #WWW2 SET WorkSum = -CRN_CurChDelta
	WHERE MMM = @M2 AND (CRN_CurChDelta < 0 AND NOT(OperVid = 1 AND OperTypeIn = 0))
  END

  IF @Str3 = '�������, ���' --and 1=2
  BEGIN
 	UPDATE #WWW2 SET WorkSum = CASE WHEN OperVid = 4 THEN
     OperSummSysCur 
    ELSE 
      CASE WHEN OperRateDeltaCur < 0 AND id_Goods IS NOT NULL AND OperTypeIn = 0 AND Koeff = 0 THEN 
        OperTotalDeltaCur - CRN_CurChDelta
      ELSE 
        OperTotalDeltaCur END 
    END
        WHERE MMM = @M2 AND (
    ((id_Goods IS NOT NULL AND OperTypeIn = 0 AND Koeff = 0) OR (OperVid = 4 AND OperTypeIn = 0))
    AND id_Repr IS NOT NULL AND NOT (OperVid = 1 AND OperTypeIn = 0 AND OperTotalDeltaCur < 0 AND Koeff = 0) -- ��������� ��������, � ������������� ��������
      )
    	
	UPDATE #WWW2 SET WorkSum = CASE WHEN PriceInv IS NOT NULL THEN -CRN_OperSum_Inv ELSE -OperSummSysCur * CASE WHEN OperVid = 4 THEN -1 ELSE 1 END END
	WHERE MMM = @M2 AND (Koeff = 1)

    	UPDATE #WWW2 SET WorkSum = -OperSummSysCur
	WHERE MMM = @M2  AND (id_Manufact_Ext  =39 AND id_WareHouse IS NOT NULL) AND OperTypeIn = 1 AND Koeff = 0


    	UPDATE #WWW2 SET WorkSum = -OperTotalDeltaCur
	WHERE MMM = @M2  AND id_ContrAgent=4329 AND NOT(OperVid = 1 AND OperTypeIn = 0)


  END

-- ****************

 /*
select sum(W.WorkSum), count(*) FROM #WWW W
select sum(R.WorkSum), count(*)  from aa_R R


select R.id_Oper, W.id_Oper, R.WorkSum, W.WorkSum
FROM #WWW W
LEFT JOIN aa_R R ON W.id_Oper = R.id_Oper AND Isnull(W.id_Goods, -1) = Isnull(R.id_Goods, -1) AND W.WorkSum = R.WorkSum 
where R.id_Oper is null
return
*/
 --select sum(WorkSum) from #WWW2 WHERE WorkSum IS NOT NULL --return

 -- SELECT OC.* INTO #Z FROM VW_Oper_WArc_Oper_New OC (NOLOCK) JOIN #WWW2 T ON OC.ID_Oper = T.ID_Oper AND Isnull(OC.id_OperWare, -1) = T.id_OperWare 
 -- WHERE WorkSum IS NOT NULL

--select WorkSum, OC.id_OperWare, ID_Oper INTO AAA_T1  from #WWW2 OC return

 

  SELECT WorkSum, OC.*
  FROM #WWW2 T 
  JOIN VW_Oper_WArc_Oper_New OC (NOLOCK) ON OC.ID_Oper = T.ID_Oper AND Isnull(OC.id_OperWare, -1) = T.id_OperWare    
  WHERE ISNULL(WorkSum, 0) <> 0 -- ZZZ = @Str3 OR @Str3 IS NULL
  ORDER BY WorkSum

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[BJ_TreeGetList]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[BJ_TreeGetList]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO











CREATE PROCEDURE BJ_TreeGetList
  @id_BJ_Obj INT,
  @isDeb BIT = NULL,
  @Mode INT = 0,
  @id_Oper INT = NULL,
  @DateRep DATETIME = NULL
AS

SET NOCOUNT ON
CREATE TABLE #RRR (
	OrderNum int,
	isDeb bit ,
	Name varchar (255),
	id_Acc int ,
	id_ContrAgent int ,
	id_BJ_Tree int ,
	PID int ,
	id_BJ_Item int ,
	ExtID int,
        PlanIn FLOAT, 
        PlanDelta FLOAT, 
        PlanCorrect FLOAT, APlan FLOAT,
        ALevel INT, 
        S_Pay FLOAT, S_Off FLOAT, Trez FLOAT, isInState BIT, BlackList INT
) 

INSERT INTO #RRR(OrderNum, isDeb, Name, id_BJ_Tree, PID, ExtID)
SELECT OrderNum=OrdNum_T, isDeb, Name, 
id_BJ_Tree, 
PID, ExtID
FROM BJ_Tree (NOLOCK) WHERE id_BJ_Obj = @id_BJ_Obj AND Disabled = 0
AND (isDeb = @isDeb OR @isDeb IS NULL)

UPDATE #RRR SET PID = NULL WHERE NOT PID IN (SELECT id_BJ_Tree FROM #RRR (NOLOCK))

INSERT INTO #RRR(OrderNum, isDeb, Name, 
id_Acc, id_ContrAgent, id_BJ_Tree, 
PID, id_BJ_Item, ExtID, PlanIn, PlanDelta, PlanCorrect, isInState, BlackList)
SELECT OrderNum=OrdNum_i, isDeb, Name = COALESCE(A.Name, CA.Name, I.Name), 
I.id_Acc, I.id_ContrAgent, id_BJ_Tree = -1, 
PID = I.id_BJ_Tree, id_BJ_Item , ExtID, PlanIn, PlanDelta, PlanCorrect, ISNULL(isInState, 0),
CASE WHEN T.ExtID = -13 THEN 1 ELSE 0 END
FROM BJ_Item I (NOLOCK) 
JOIN BJ_Tree T (NOLOCK) ON T.id_BJ_Tree = I.id_BJ_Tree
LEFT JOIN Acc_Acc A (NOLOCK) ON A.id_Acc = I.id_Acc
LEFT JOIN CA_ContrAgent CA (NOLOCK) ON CA.id_ContrAgent = I.id_ContrAgent
WHERE T.id_BJ_Obj = @id_BJ_Obj AND I.Disabled = 0 AND T.Disabled = 0
AND (isDeb = @isDeb OR @isDeb IS NULL)

UPDATE #RRR SET PlanIn = NULL, PlanDelta = NULL, PlanCorrect = NULL WHERE BlackList = 1

SELECT id_Acc 
INTO #RRR_ACC
FROM #RRR (NOLOCK) 
WHERE id_Acc IS NOT NULL
GROUP BY id_Acc

SELECT id_ContrAgent 
INTO #RRR_CA
FROM #RRR (NOLOCK) 
WHERE id_ContrAgent IS NOT NULL
GROUP BY id_ContrAgent

DECLARE @Level INT

SET @Level = 0

UPDATE #RRR SET ALevel = @Level WHERE PID IS NULL

WHILE 1 = 1
BEGIN
  SET @Level = @Level + 1

  UPDATE #RRR SET  ALevel = @Level WHERE PID IN (SELECT id_BJ_Tree FROM #RRR (NOLOCK) WHERE ALevel = @Level - 1)

  IF @@ROWCOUNT = 0
    BREAK
END

SELECT @Level = MAX(ALevel) - 1 FROM #RRR (NOLOCK)

WHILE @Level >= 0
BEGIN
  UPDATE #RRR SET PlanIn = T.PlanIn, PlanDelta = T.PlanDelta, PlanCorrect = T.PlanCorrect
  FROM (
         SELECT PID, PlanIn = SUM(ISNULL(PlanIn, 0)), PlanDelta = SUM(ISNULL(PlanDelta, 0)), PlanCorrect = SUM(ISNULL(PlanCorrect, 0))
         FROM #RRR (NOLOCK) 
         WHERE ALevel = @Level + 1 
         GROUP BY PID) T
  WHERE ALevel = @Level AND T.PID = #RRR.id_BJ_Tree

  SET @Level = @Level - 1
END

  DECLARE @StartDate DATETIME, @StopDate DATETIME, @id_business INT, @DateCheck DATETIME
  SELECT @DateCheck = DateCheck, @StartDate = StartDate, @StopDate = StopDate + 1, @id_business = id_business FROM BJ_Obj (NOLOCK) WHERE id_BJ_Obj = @id_BJ_Obj

IF @Mode = 1 and @DateCheck is not null
BEGIN

  
  CREATE TABLE #T_OP (ID INT IDENTITY (1, 1), CRN_OLD_OperSum_Offer FLOAT, CRN_OLD_OperSum FLOAT, 
                      id_Acc INT, id_Acc_Ext INT, id_ContrAgent INT, id_BJ_Item int, OperVid INT, Koeff INT, OperTypeIn INT)


  CREATE TABLE #OFFF(CRN_OLD_OperSum_Offer FLOAT)

  SELECT OC.id_Oper
  INTO #www 
  FROM OP_Oper2 OC (NOLOCK)
  LEFT JOIN BJ_OperRel ORel (NOLOCK) ON ORel.id_Oper = OC.id_Oper AND ORel.id_BJ_Obj = @id_BJ_Obj
  WHERE (OC.id_Oper = @id_Oper OR @id_Oper IS NULL) AND
  OC.OperVid in (-1, 2, 102 ) AND HidedOper = 0 AND Deleted = 0 AND OC.CheckDate IS NOT NULL AND -- OperVid in (-1, 2, 102)
  @id_business = OC.id_business AND
  (OC.DateCreate >= @StartDate AND OC.DateCreate <= @StopDate)
  AND (@DateRep IS NULL OR @id_Oper IS NOT NULL OR OC.DateCreate <= @DateRep)
  AND (ISNULL(NotUse, 0) = 0)
--  and OC.id_Oper <= 224408 -- 225769
--and OC.OperVid = -1
  GROUP BY OC.id_Oper

  INSERT INTO #T_OP(CRN_OLD_OperSum_Offer, CRN_OLD_OperSum, id_Acc, id_Acc_Ext, id_ContrAgent, id_BJ_Item, OperVid, Koeff, OperTypeIn)
  SELECT CRN_OLD_OperSum_Offer, CRN_OLD_OperSum, OC.id_Acc, id_Acc_Ext, 
  id_ContrAgent = ISNULL(id_ContrAgent_Ex, CR.id_ContrAgent), 
  BI.id_BJ_Item, --id_BJ_Item = CASE WHEN T.id_BJ_Obj IS NULL THEN NULL ELSE BI.id_BJ_Item END, 
  OperVid, Koeff, OperTypeIn 
  FROM VW_Oper_WArc_prev_New OC
  JOIN #www w (NOLOCK) ON w.id_Oper = OC.id_Oper 
  LEFT JOIN CA_Repr CR (NOLOCK) ON CR.id_Repr = OC.id_Repr
  LEFT JOIN BJ_OperRel ORel (NOLOCK) ON ORel.id_Oper = OC.id_Oper AND ORel.id_BJ_Obj = @id_BJ_Obj
  LEFT JOIN BJ_Item BI (NOLOCK) ON BI.id_BJ_Item = ORel.id_BJ_Item AND BI.Disabled = 0
 -- LEFT JOIN BJ_Tree T (NOLOCK) ON T.id_BJ_Tree = BI.id_BJ_Tree AND BI.Disabled = 0 AND T.id_BJ_Obj = @id_BJ_Obj

select id_Acc INTO #D_A FROM #RRR (NOLOCK) WHERE BlackList = 1 AND id_Acc IS NOT NULL GROUP BY id_Acc
select id_ContrAgent INTO #D_C FROM #RRR (NOLOCK) WHERE BlackList = 1 AND id_ContrAgent IS NOT NULL GROUP BY id_ContrAgent

  DELETE FROM #T_OP WHERE id_Acc IN (SELECT id_Acc FROM #D_A (NOLOCK))
  DELETE FROM #T_OP WHERE id_Acc_Ext IN (SELECT id_Acc FROM #D_A (NOLOCK))
  DELETE FROM #T_OP WHERE id_ContrAgent IN (SELECT id_ContrAgent FROM #D_C (NOLOCK))
--select * FROM #T_OP RETURN

  -- ����� -- 
  
  SELECT CRN_OLD_OperSum = SUM(CRN_OLD_OperSum), id_Acc 
  INTO #T_333
  FROM (
       SELECT CRN_OLD_OperSum = ((ISNULL(-CRN_OLD_OperSum, 0))), 
       id_Acc = id_Acc

  FROM #T_OP G (NOLOCK)
  WHERE G.id_Acc IS NOT NULL 
 
  UNION ALL
 
  SELECT CRN_OLD_OperSum = ((ISNULL(CRN_OLD_OperSum, 0))), 
       id_Acc = G.id_Acc_Ext
  FROM #T_OP G (NOLOCK)
  WHERE G.id_Acc_Ext IS NOT NULL) T
  GROUP BY id_Acc

  UPDATE #RRR SET S_Pay = (SELECT CASE WHEN isDeb = 1 THEN -1 ELSE 1 END * SUM(CRN_OLD_OperSum) FROM #T_333 T (NOLOCK) WHERE T.id_Acc = #RRR.id_Acc ) WHERE isInState = 0 AND id_Acc IS NOT NULL

--select * FROM #RRR ORDER BY id_Acc
--SELECT * FROM #T_333
--SELECT * FROM #T_OP

  -- �����  ����� -- 

  -- �� -- 
  
  SELECT CRN_OLD_OperSum = SUM(CRN_OLD_OperSum_Offer), id_ContrAgent, OperVid 
  INTO #T_CA
  FROM #T_OP G (NOLOCK)
  WHERE G.id_ContrAgent IS NOT NULL AND id_BJ_Item IS NULL AND Koeff = 0 AND OperVid <> -1 AND OperVid <> 4
  GROUP BY id_ContrAgent, OperVid

  UPDATE #RRR SET S_Pay = (
                   SELECT CASE WHEN isDeb = 1 THEN -1 ELSE 1 END * SUM(CRN_OLD_OperSum) 
                   FROM #T_CA T (NOLOCK) 
                   WHERE T.id_ContrAgent = #RRR.id_ContrAgent
                   AND OperVid <> 4) 
  WHERE isInState = 0 AND id_ContrAgent IS NOT NULL


  SELECT CRN_OLD_OperSum = SUM(-CRN_OLD_OperSum_Offer), id_ContrAgent, OperVid, id_BJ_Item --555
  INTO #T_CA_Off
  FROM #T_OP G (NOLOCK)
  WHERE G.id_ContrAgent IS NOT NULL AND Koeff = 0 AND OperVid = 4
  GROUP BY id_ContrAgent, OperVid, id_BJ_Item 

  UPDATE #RRR SET S_Off = (
                   SELECT CASE WHEN isDeb = 1 THEN -1 ELSE 1 END * SUM(-CRN_OLD_OperSum) 
                   FROM #T_CA_Off T (NOLOCK) 
                   WHERE T.id_ContrAgent = #RRR.id_ContrAgent
                   AND OperVid = 4) 
  WHERE isInState = 0 AND id_ContrAgent IS NOT NULL


  INSERT INTO #OFFF(CRN_OLD_OperSum_OFFER) 
  SELECT SUM(/*CASE WHEN isDeb = 1 THEN -1 ELSE 1 END **/ -CRN_OLD_OperSum) 
  FROM #T_CA_Off T (NOLOCK),  #RRR (NOLOCK)
  WHERE T.id_ContrAgent = #RRR.id_ContrAgent AND OperVid = 4 
  AND isInState = 0 AND #RRR.id_ContrAgent IS NOT NULL
  AND T.id_BJ_Item IS NULL
 
--SELECT * FROM #T_OP
--SELECT * FROM #T_CA return

  -- ��  ����� -- 

  -- �����  ����� -- 

  -- ������ -- 
  
  SELECT CRN_OLD_OperSum = SUM(CRN_OLD_OperSum_Offer), id_BJ_Item, OperVid, id_ContrAgent 
  INTO #T_Artc
  FROM #T_OP G (NOLOCK)
  WHERE id_BJ_Item IS NOT NULL AND OperVid <> -1
  GROUP BY id_BJ_Item, OperVid, id_ContrAgent

--select * from #T_Artc

  UPDATE #RRR SET S_Pay = (
                   SELECT CASE WHEN isDeb = 1 THEN -1 ELSE 1 END * SUM(CRN_OLD_OperSum) 
                   FROM #T_Artc T (NOLOCK) 
                   WHERE T.id_BJ_Item = #RRR.id_BJ_Item
                   AND OperVid <> 4) 
  WHERE isInState = 0 AND id_Acc IS NULL AND id_ContrAgent IS NULL


  UPDATE #RRR SET S_Off = (
                   SELECT 
                          CASE WHEN isDeb = 1 THEN -1 ELSE 1 END * SUM(CASE WHEN C.id_ContrAgent IS NULL THEN -1 ELSE 1 END * -CRN_OLD_OperSum) --555
                   FROM #T_Artc T (NOLOCK) 
                   LEFT JOIN #RRR_CA C (NOLOCK) ON C.id_ContrAgent = T.id_ContrAgent
                   WHERE T.id_BJ_Item = #RRR.id_BJ_Item
                   AND OperVid = 4) 
  WHERE isInState = 0 AND id_Acc IS NULL AND id_ContrAgent IS NULL

/*  INSERT INTO #OFFF(CRN_OLD_OperSum_OFFER) 
  SELECT SUM(CASE WHEN isDeb = 1 THEN -1 ELSE 1 END * CRN_OLD_OperSum)
  FROM #T_Artc T (NOLOCK),  #RRR (NOLOCK)
  WHERE T.id_BJ_Item = #RRR.id_BJ_Item AND OperVid = 4 
  AND isInState = 0 AND #RRR.id_Acc IS NULL AND #RRR.id_ContrAgent IS NULL
*/

--SELECT * FROM #T_Artc

  -- ������  ����� -- 

  IF @DateCheck IS NOT NULL
  BEGIN
    SELECT id_Acc3 = id_Acc, id_ContrAgent3 = id_ContrAgent, PlanIn3 = PlanIn
    INTO #R_IN
    FROM  #RRR (NOLOCK)
    WHERE isInState = 1 AND isDeb = 1 AND ISNULL(PlanIn, 0) <> 0

--select * from #R_IN RETURN

    UPDATE #RRR 
      SET S_Pay = ISNULL(S_Pay, 0) + PlanIn3
    FROM #R_IN R (NOLOCK) WHERE R.id_Acc3 = id_Acc

    UPDATE #RRR 
      SET S_Pay = ISNULL(S_Pay, 0) + PlanIn3
    FROM #R_IN R (NOLOCK) WHERE R.id_ContrAgent3 = id_ContrAgent
  END

--select * FROM #RRR Where id_Acc=530
  SELECT @Level = MAX(ALevel) - 1 FROM #RRR (NOLOCK)

  WHILE @Level >= 0
  BEGIN
    UPDATE #RRR SET S_Pay = T.S_Pay, S_Off = T.S_Off
    FROM (
         SELECT PID, S_Pay = SUM(ISNULL(S_Pay, 0)), S_Off = SUM(ISNULL(S_Off, 0))
         FROM #RRR (NOLOCK) 
         WHERE ALevel = @Level + 1 
         GROUP BY PID) T
    WHERE ALevel = @Level AND T.PID = #RRR.id_BJ_Tree

    SET @Level = @Level - 1
  
  END
--select * FROM #RRR Where id_Acc=530

IF @isDeb IS NULL
BEGIN
  DECLARE @V1 FLOAT, @V2 FLOAT, @V3 FLOAT, @V4 FLOAT, @S_Pay FLOAT, @S_Off FLOAT

  if @Mode = 1 
  BEGIN

    SELECT @V1 = SUM(ISNULL(CRN_OLD_OperSum_Offer, 0)) 
    FROM #OFFF OP (NOLOCK) 
   --wHERE id_BJ_Item IS NULL

    IF ABS(ISNULL(@V1, 0)) > 0.005
      INSERT INTO #RRR(ALevel, Name, id_BJ_Tree, id_BJ_Item, isDeb, OrderNum, S_Off)
      SELECT ALevel = 0, 
             Name = CASE WHEN @V1 < 0 THEN '������ � �������' ELSE '������� � �������' END, 
            id_BJ_Tree = -1, -10, 
            isDeb = CASE WHEN @V1 > 0 THEN 1 ELSE 0 END, OrderNum = 2999, 
            S_Off = ABS(ISNULL(@V1, 0))
    


    SELECT @V1 = SUM(ISNULL(-CRN_OLD_OperSum, 0)) 
    FROM #T_OP OP (NOLOCK) 
    LEFT JOIN #RRR_Acc R (NOLOCK) ON R.id_Acc = OP.id_Acc
    LEFT JOIN #RRR_CA R4 (NOLOCK) ON R4.id_ContrAgent = OP.id_ContrAgent
    WHERE OP.id_BJ_Item is null and OP.Koeff=-1 AND COALESCE(R4.id_ContrAgent, R.id_Acc) IS NOT NULL

/*    SELECT *
    FROM #T_OP OP (NOLOCK) 
    LEFT JOIN #RRR_Acc R (NOLOCK) ON R.id_Acc = OP.id_Acc
    LEFT JOIN #RRR_CA R4 (NOLOCK) ON R4.id_ContrAgent = OP.id_ContrAgent
    WHERE OP.id_BJ_Item is null and OP.Koeff=-1 AND COALESCE(R4.id_ContrAgent, R.id_Acc) IS NOT NULL
return*/

    IF ISNULL(@V1, 0) <> 0
      INSERT INTO #RRR(ALevel, Name, id_BJ_Tree, id_BJ_Item, isDeb, OrderNum, S_Pay)
      SELECT ALevel = 0, '���������� �������', id_BJ_Tree = -1, -1, 
            isDeb = CASE WHEN @V1 > 0 THEN 1 ELSE 0 END, OrderNum = 2999, 
            S_Pay = ABS(ISNULL(@V1, 0))


    SELECT @V1 = SUM(ISNULL(-CRN_OLD_OperSum, 0)) 
    FROM #T_OP OP (NOLOCK) 
    LEFT JOIN #RRR_Acc R (NOLOCK) ON R.id_Acc = OP.id_Acc
    LEFT JOIN #RRR_CA R4 (NOLOCK) ON R4.id_ContrAgent = OP.id_ContrAgent
    WHERE OP.id_BJ_Item is null and OP.Koeff=1 AND COALESCE(R4.id_ContrAgent, R.id_Acc) IS NOT NULL


    IF ISNULL(@V1, 0) <> 0
      INSERT INTO #RRR(ALevel, Name, id_BJ_Tree, id_BJ_Item, isDeb, OrderNum, S_Pay)
      SELECT ALevel = 0, '���������� �������', id_BJ_Tree = -1, -2, 
            isDeb = CASE WHEN @V1 > 0 THEN 1 ELSE 0 END, OrderNum = 2999, 
            S_Pay = ABS(ISNULL(@V1, 0))


--select * from #T_OP RETURN

    SELECT @V1 = SUM(ISNULL(-CRN_OLD_OperSum_Offer, 0)) 
    FROM #T_OP OP (NOLOCK) 
    JOIN #RRR_Acc R2 (NOLOCK) ON R2.id_Acc = OP.id_Acc 
    LEFT JOIN #RRR_CA R (NOLOCK) ON R.id_ContrAgent = OP.id_ContrAgent
    WHERE OP.id_ContrAgent  is not null AND R.id_ContrAgent is null and OP.id_BJ_Item is null and Koeff=0


    IF ISNULL(@V1, 0) <> 0 
      INSERT INTO #RRR(ALevel, Name, id_BJ_Tree, id_BJ_Item, isDeb, OrderNum, S_Pay)
      SELECT ALevel = 0, '���������� ����������� - ������', id_BJ_Tree = -1, -3, 
            isDeb = CASE WHEN @V1 > 0 THEN 1 ELSE 0 END, 
            OrderNum = 2999, 
            S_Pay = ABS(ISNULL(@V1, 0))

 
SET @S_Off = NULL
    SELECT @S_Off = SUM(ISNULL(-CRN_OLD_OperSum, 0)) 
    FROM #T_OP OP (NOLOCK) 
    LEFT JOIN #RRR_CA R (NOLOCK) ON R.id_ContrAgent = OP.id_ContrAgent
    WHERE OP.id_ContrAgent is not null AND R.id_ContrAgent is null and Koeff=0 AND OperVid=4 AND OP.id_BJ_Item is NOT null
    
IF ISNULL(@S_Off, 0) <> 0
      INSERT INTO #RRR(ALevel, Name, id_BJ_Tree, id_BJ_Item, isDeb, OrderNum, S_Pay, S_Off)
      SELECT ALevel = 0, '���������� ����������� - ������ - ' + CASE WHEN @S_Off < 0 THEN '�������' ELSE '�������' END, id_BJ_Tree = -1, -33, 
            isDeb = CASE WHEN @S_Off < 0 THEN 1 ELSE 0 END, OrderNum = 2999, 
            Null,
            ABS(ISNULL(@S_Off, 0))


    SELECT @V1 = SUM(ISNULL(CRN_OLD_OperSum, 0)) 
    FROM #T_OP OP (NOLOCK) 
    JOIN #RRR_Acc R2 (NOLOCK) ON R2.id_Acc = OP.id_Acc_Ext  
    LEFT JOIN #RRR_Acc R (NOLOCK) ON R.id_Acc = OP.id_Acc
    WHERE OP.id_Acc is not null AND R.id_Acc is null and OP.id_BJ_Item is null and Koeff=0

    SELECT @V3 = SUM(ISNULL(CRN_OLD_OperSum, 0)) 
    FROM #T_OP OP (NOLOCK) 
    JOIN #RRR_CA R2 (NOLOCK) ON R2.id_ContrAgent = OP.id_ContrAgent  
    LEFT JOIN #RRR_Acc R (NOLOCK) ON R.id_Acc = OP.id_Acc
    WHERE OP.id_Acc is not null AND R.id_Acc is null and OP.id_BJ_Item is null and Koeff=0

    SELECT @V4 = SUM(ISNULL(CRN_OLD_OperSum, 0)) 
    FROM #T_OP OP (NOLOCK) 
    JOIN #RRR R2 (NOLOCK) ON R2.id_BJ_Item = OP.id_BJ_Item  
    LEFT JOIN #RRR_Acc R (NOLOCK) ON R.id_Acc = OP.id_Acc
    LEFT JOIN #RRR_CA R4 (NOLOCK) ON R4.id_ContrAgent = OP.id_ContrAgent
    WHERE OP.id_Acc is not null AND R.id_Acc is null and OP.id_BJ_Item is NOT null 
    AND COALESCE(R4.id_ContrAgent, R.id_Acc) IS NULL

    

    SELECT @V2 = SUM(ISNULL(-CRN_OLD_OperSum, 0)) 
    FROM #T_OP OP (NOLOCK) 
    JOIN #RRR_Acc R2 (NOLOCK) ON R2.id_Acc = OP.id_Acc 
    LEFT JOIN #RRR R (NOLOCK) ON R.id_Acc = OP.id_Acc_Ext
    WHERE OP.id_Acc_Ext is not null AND R.id_Acc is null and OP.id_BJ_Item is null and Koeff=0

  SET @V1 = ISNULL(@V1, 0) + ISNULL(@V2, 0) + ISNULL(@V3, 0) + ISNULL(@V4, 0)
  IF ISNULL(@V1, 0) + ISNULL(@V2, 0) <> 0
      INSERT INTO #RRR(ALevel, Name, id_BJ_Tree, id_BJ_Item, isDeb, OrderNum, S_Pay)
      SELECT ALevel = 0, '���������� �����',id_BJ_Tree = -1,  -4, 
            isDeb = CASE WHEN @V1 > 0 THEN 1 ELSE 0 END, OrderNum = 2999, 
            S_Pay = ABS(ISNULL(@V1, 0))


  
SELECT id_Acc, isDeb  INTO #RRR_EEE FROM #RRR (NOLOCK) WHERE id_Acc IS NOT NULL AND isInState = 0 GROUP BY id_Acc, isDeb 
--SELECT id_Acc, isDeb  INTO #RRR_EEE_CA FROM #RRR (NOLOCK) WHERE id_ContrAgent IS NOT NULL AND isInState = 0 GROUP BY id_ContrAgent, isDeb 

    SELECT @V1 = SUM(ISNULL(-CRN_OLD_OperSum /** CASE WHEN R.isDeb = 0 THEN -1 ELSE 1 END*/, 0)) 
    FROM #T_OP OP (NOLOCK) 
    JOIN #RRR_EEE R (NOLOCK) ON R.id_Acc = OP.id_Acc 
    WHERE OP.OperVid = -1

    SELECT @V2 = SUM(ISNULL(CRN_OLD_OperSum_Offer - CRN_OLD_OperSum, 0)) 
    FROM #T_OP OP (NOLOCK) 
    LEFT JOIN #RRR_CA R (NOLOCK) ON R.id_ContrAgent = OP.id_ContrAgent 
    LEFT JOIN #RRR_Acc R2 (NOLOCK) ON R2.id_Acc = OP.id_Acc 
    WHERE (ISNULL(CRN_OLD_OperSum_Offer - CRN_OLD_OperSum, 0) <> 0) AND OP.id_ContrAgent IS NOT NULL AND OP.Koeff = 0
    AND COALESCE(R.id_ContrAgent, R2.id_Acc) IS NOT NULL
    AND OP.id_BJ_Item IS NULL


    SELECT @V3 = SUM(ISNULL(CRN_OLD_OperSum_Offer - CRN_OLD_OperSum, 0)) 
    FROM #T_OP OP (NOLOCK) 
    WHERE (ISNULL(CRN_OLD_OperSum_Offer - CRN_OLD_OperSum, 0) <> 0) AND OP.id_BJ_Item IS NOT NULL


    SET @V1 = ISNULL(@V1, 0) + ISNULL(@V2, 0) + ISNULL(@V3, 0)
   
    IF ISNULL(@V1, 0) <> 0
      INSERT INTO #RRR(ALevel, Name, id_BJ_Tree, id_BJ_Item, isDeb, OrderNum, S_Pay)
      SELECT ALevel = 0, 
            Name = CASE WHEN @V1 < 0 THEN '�������� ������' ELSE '�������� �������' END, -1, id_BJ_Tree = -5, 
            isDeb = CASE WHEN @V1 > 0 THEN 1 ELSE 0 END, OrderNum = 2999, 
            S_Pay = ABS(ISNULL(@V1, 0))

  END


END
END

IF @isDeb IS NULL
BEGIN

  SELECT @V1 = SUM(ISNULL(PlanIn, 0)), @V2 = SUM(ISNULL(PlanDelta, 0)) , @V3 = SUM(ISNULL(PlanCorrect, 0)),
                @S_Pay = SUM(ISNULL(S_Pay, 0)), @S_Off = SUM(ISNULL(S_Off, 0))  
  FROM #RRR (NOLOCK)
  WHERE isDeb = 1 AND PID IS NULL

  INSERT INTO #RRR(ALevel, Name, id_BJ_Tree, isDeb, OrderNum, PlanIn, PlanDelta, PlanCorrect, S_Pay, S_Off)
  SELECT ALevel = 0, '���� �� �������', id_BJ_Tree = -1, isDeb = 1, OrderNum = 3000, PlanIn = ISNULL(@V1, 0), PlanDelta = ISNULL(@V2, 0), PlanCorrect = ISNULL(@V3, 0), 
  S_Pay = ISNULL(@S_Pay, 0), S_Off = ISNULL(@S_Off, 0) 


  SELECT @V1 = SUM(ISNULL(PlanIn, 0)), @V2 = SUM(ISNULL(PlanDelta, 0)), @V3 = SUM(ISNULL(PlanCorrect, 0)),
                @S_Pay = SUM(ISNULL(S_Pay, 0)), @S_Off = SUM(ISNULL(S_Off, 0))    
  FROM #RRR (NOLOCK)
  WHERE isDeb = 0 AND PID IS NULL

  INSERT INTO #RRR(ALevel, Name, id_BJ_Tree, isDeb, OrderNum, PlanIn, PlanDelta, PlanCorrect, S_Pay, S_Off)
  SELECT ALevel = 0, '���� �� ��������', id_BJ_Tree = -1, isDeb = 0, OrderNum = -1, PlanIn = ISNULL(@V1, 0), PlanDelta = ISNULL(@V2, 0), PlanCorrect = ISNULL(@V3, 0)  ,
          S_Pay = ISNULL(@S_Pay, 0), S_Off = ISNULL(@S_Off, 0) 
 
  SELECT @V1 = SUM(ISNULL(PlanIn * CASE WHEN isDeb = 1 THEN 1 ELSE -1 END, 0)), 
         @V2 = SUM(ISNULL(PlanDelta * CASE WHEN isDeb = 1 THEN 1 ELSE -1 END, 0)) , 
         @V3 = SUM(ISNULL(PlanCorrect * CASE WHEN isDeb = 1 THEN 1 ELSE -1 END, 0)), 
         @S_Pay = SUM(ISNULL(S_Pay * CASE WHEN isDeb = 1 THEN 1 ELSE -1 END, 0)), 
         @S_Off = SUM(ISNULL(S_Off * CASE WHEN isDeb = 1 THEN 1 ELSE -1 END, 0)) 
  FROM #RRR (NOLOCK)
  WHERE OrderNum = 3000 OR OrderNum = -1


  INSERT INTO #RRR(ALevel, Name, id_BJ_Tree, isDeb, OrderNum, PlanIn, PlanDelta, PlanCorrect, PID, S_Pay, S_Off)
  SELECT ALevel = 0, '������', id_BJ_Tree = -1, isDeb = 1, OrderNum = 4000, PlanIn = ISNULL(@V1, 0), PlanDelta = ISNULL(@V2, 0), PlanDelta = ISNULL(@V3, 0),  PID = -8,
  S_Pay = ISNULL(@S_Pay, 0), S_Off = ISNULL(@S_Off, 0) 
END

UPDATE #RRR SET OrderNum = -2 WHERE ExtID = 1
--UPDATE #RRR SET OrderNum = 20 WHERE ExtID = 2
UPDATE #RRR SET OrderNum = 2000 WHERE ExtID = 3

IF @Mode = 1 
BEGIN
  UPDATE #RRR SET APlan = ISNULL(PlanIn, 0) + ISNULL(PlanDelta, 0) + ISNULL(PlanCorrect, 0),
                  Trez = ISNULL(PlanIn, 0) + ISNULL(PlanDelta, 0) + ISNULL(PlanCorrect, 0) 
                      --    + CASE WHEN id_Acc IS NULL THEN -1 ELSE 1 END * CASE WHEN id_ContrAgent IS NOT NULL AND isDeb = 0 THEN -1 ELSE 1 END * CASE WHEN isDeb = 0 THEN -1 ELSE 1 END * 
                          - CASE WHEN id_Acc IS NOT NULL AND isDeb = 0 THEN -1 ELSE 1 END * ISNULL(S_Pay, 0) 
                  --        + CASE WHEN isDeb = 0 THEN -1 ELSE 1 END * 
                          - ISNULL(S_Off, 0)
  

END

DELETE FROM #RRR WHERE id_BJ_Tree<0 AND ABS(S_Pay) < 0.005 AND ALevel = 0 AND id_BJ_Item < 0

SET NOCOUNT OFF

SELECT * 
FROM #RRR (NOLOCK)
ORDER BY isDeb DESC, 
ALevel,
OrderNum
, Name DESC
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

